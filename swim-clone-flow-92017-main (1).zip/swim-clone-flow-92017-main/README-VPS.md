# 🚀 Guia Completo de Deploy VPS - Versiani Swim + Vega Checkout

Este guia contém todas as instruções para migrar o projeto para um VPS e integrar com Vega Checkout.

---

## 📋 Pré-requisitos

- ✅ VPS contratado (TurboCloud, DigitalOcean, AWS EC2, etc.)
- ✅ Domínio registrado
- ✅ Credenciais da Vega Checkout (API Key)
- ✅ SSH configurado no VPS

---

## 🎯 FASE 1: Configurar VPS (45 minutos)

### 1.1 Conectar ao VPS

```bash
ssh root@SEU_IP_DO_VPS
```

### 1.2 Atualizar Sistema

```bash
apt update && apt upgrade -y
```

### 1.3 Instalar Node.js 20.x

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
node --version  # Verificar: deve mostrar v20.x
npm --version   # Verificar
```

### 1.4 Instalar PM2 (Gerenciador de Processos)

```bash
npm install -g pm2
pm2 --version
```

### 1.5 Instalar Nginx

```bash
apt install -y nginx
systemctl status nginx  # Verificar se está rodando
```

### 1.6 Instalar Certbot (SSL Gratuito)

```bash
apt install -y certbot python3-certbot-nginx
```

### 1.7 Criar Usuário da Aplicação

```bash
adduser --disabled-password --gecos "" appuser
su - appuser
```

### 1.8 Configurar Firewall

```bash
# Voltar para root
exit

# Configurar firewall
ufw allow 22    # SSH
ufw allow 80    # HTTP
ufw allow 443   # HTTPS
ufw enable
ufw status
```

---

## 🎯 FASE 2: Transferir Código para VPS (20 minutos)

### 2.1 No seu computador local

**1. Build do Frontend:**

```bash
npm run build
# Isso cria a pasta dist/
```

**2. Comprimir arquivos:**

```bash
# Comprimir frontend
tar -czf frontend.tar.gz dist/

# Comprimir backend
tar -czf backend.tar.gz backend/
```

**3. Enviar para VPS:**

```bash
# Substituir SEU_IP pelo IP do VPS
scp frontend.tar.gz appuser@SEU_IP:/home/appuser/
scp backend.tar.gz appuser@SEU_IP:/home/appuser/
```

### 2.2 No VPS (como appuser)

```bash
ssh appuser@SEU_IP

# Criar estrutura de pastas
mkdir -p versiani-app
cd versiani-app

# Descompactar arquivos
tar -xzf ../frontend.tar.gz
mv dist frontend

tar -xzf ../backend.tar.gz

# Limpar
rm ../frontend.tar.gz ../backend.tar.gz
```

---

## 🎯 FASE 3: Configurar Backend (15 minutos)

### 3.1 Instalar Dependências

```bash
cd ~/versiani-app/backend
npm install
```

### 3.2 Configurar Variáveis de Ambiente

```bash
cp .env.example .env
nano .env
```

**Edite o arquivo .env:**

```bash
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://seudominio.com
VEGA_API_URL=https://api.vegacheckout.com.br
VEGA_API_KEY=sua_chave_vega_aqui
```

**Pressione:** `Ctrl+O` (salvar), `Enter`, `Ctrl+X` (sair)

### 3.3 Testar Backend

```bash
npm start
# Deve mostrar: "Backend Versiani rodando na porta 3001"
# Pressione Ctrl+C para parar
```

### 3.4 Iniciar com PM2

```bash
pm2 start server.js --name versiani-backend
pm2 save
pm2 startup
# Copie e execute o comando mostrado
```

**Verificar:**

```bash
pm2 status
pm2 logs versiani-backend
```

---

## 🎯 FASE 4: Configurar Nginx (20 minutos)

### 4.1 Criar Configuração (como root)

```bash
# Voltar para root
exit

# Criar arquivo de configuração
nano /etc/nginx/sites-available/versiani
```

**Cole esta configuração (substitua `seudominio.com`):**

```nginx
server {
    listen 80;
    server_name seudominio.com www.seudominio.com;

    # Frontend React
    location / {
        root /home/appuser/versiani-app/frontend;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 4.2 Ativar Configuração

```bash
ln -s /etc/nginx/sites-available/versiani /etc/nginx/sites-enabled/
nginx -t  # Testar configuração
systemctl restart nginx
```

### 4.3 Configurar DNS do Domínio

**No painel do seu provedor de domínio (Registro.br, GoDaddy, etc.):**

1. Criar registro **A** para `@` (domínio raiz):
   - Nome: `@`
   - Tipo: `A`
   - Valor: `SEU_IP_DO_VPS`
   - TTL: `3600`

2. Criar registro **A** para `www`:
   - Nome: `www`
   - Tipo: `A`
   - Valor: `SEU_IP_DO_VPS`
   - TTL: `3600`

**Aguardar propagação DNS (5 minutos a 48 horas)**

### 4.4 Instalar SSL (HTTPS)

```bash
certbot --nginx -d seudominio.com -d www.seudominio.com
```

Siga as instruções:
- Digite seu email
- Aceite os termos
- Escolha opção 2 (redirecionar HTTP para HTTPS)

**Verificar:**

```bash
certbot renew --dry-run
```

---

## 🎯 FASE 5: Configurar Vega Checkout (10 minutos)

### 5.1 Adicionar IP no Painel Vega

1. Acesse o painel Vega
2. Vá em **Configurações** → **API** → **IPs Autorizados**
3. Clique em **Adicionar IP**
4. Digite o IP do seu VPS: `SEU_IP_DO_VPS`
5. Salvar

### 5.2 Configurar Webhook Vega

1. No painel Vega, vá em **Configurações** → **Webhooks**
2. Adicione a URL: `https://seudominio.com/api/vega-webhook`
3. Selecione eventos:
   - ✅ `payment.approved`
   - ✅ `payment.pending`
   - ✅ `payment.rejected`
4. Salvar

### 5.3 Obter Credenciais Vega

1. No painel Vega, vá em **Configurações** → **API**
2. Copie:
   - **API URL** (ex: `https://api.vegacheckout.com.br`)
   - **API Key** (chave privada)

3. Atualizar `.env` no VPS:

```bash
ssh appuser@SEU_IP
nano ~/versiani-app/backend/.env
```

Cole as credenciais corretas:

```bash
VEGA_API_URL=URL_COPIADA_AQUI
VEGA_API_KEY=CHAVE_COPIADA_AQUI
```

**Reiniciar backend:**

```bash
pm2 restart versiani-backend
pm2 logs versiani-backend
```

---

## 🎯 FASE 6: Configurar Frontend (5 minutos)

### 6.1 Atualizar URL da API

**No seu computador local, edite:** `src/config/api.ts`

```typescript
export const API_CONFIG = {
  baseURL: 'https://seudominio.com',  // ← Seu domínio aqui!
  // ... resto do código
};
```

### 6.2 Rebuild e Deploy

```bash
# No seu computador
npm run build
tar -czf frontend.tar.gz dist/
scp frontend.tar.gz appuser@SEU_IP:/home/appuser/versiani-app/

# No VPS
ssh appuser@SEU_IP
cd ~/versiani-app
rm -rf frontend
tar -xzf frontend.tar.gz
mv dist frontend
rm frontend.tar.gz
```

---

## 🎯 FASE 7: Testar Tudo (15 minutos)

### 7.1 Verificar Saúde da API

```bash
curl https://seudominio.com/api/health
# Deve retornar: {"status":"ok",...}
```

### 7.2 Teste Completo no Navegador

1. Acesse `https://seudominio.com`
2. Adicione **múltiplos produtos** ao carrinho
3. Clique em **Finalizar Compra**
4. Verifique se redireciona para Vega Checkout
5. Complete um pagamento teste
6. Verifique logs do webhook:

```bash
pm2 logs versiani-backend --lines 50
```

### 7.3 Monitoramento

```bash
# Ver status
pm2 status

# Ver logs em tempo real
pm2 logs versiani-backend

# Ver logs do Nginx
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

---

## 🔄 Deploy Rápido (Próximas Atualizações)

### Usando o Script Automatizado

**1. Configure o script uma vez:**

```bash
chmod +x deploy.sh
nano deploy.sh
```

Edite as variáveis:

```bash
VPS_USER="appuser"
VPS_IP="SEU_IP_AQUI"
```

**2. Deploy com um comando:**

```bash
./deploy.sh
```

---

## 🛠️ Comandos Úteis

### Backend

```bash
# Reiniciar
pm2 restart versiani-backend

# Parar
pm2 stop versiani-backend

# Ver logs
pm2 logs versiani-backend

# Ver status
pm2 status

# Monit em tempo real
pm2 monit
```

### Nginx

```bash
# Reiniciar
systemctl restart nginx

# Testar configuração
nginx -t

# Ver logs
tail -f /var/log/nginx/error.log
```

### SSL

```bash
# Renovar SSL manualmente
certbot renew

# Testar renovação
certbot renew --dry-run
```

---

## 🚨 Troubleshooting

### Erro: "Cannot connect to backend"

```bash
# Verificar se backend está rodando
pm2 status

# Ver logs
pm2 logs versiani-backend

# Reiniciar
pm2 restart versiani-backend
```

### Erro: "Vega API not responding"

```bash
# Verificar credenciais
cat ~/versiani-app/backend/.env

# Testar conexão
curl -X POST https://api.vegacheckout.com.br/health \
  -H "Authorization: Bearer SUA_API_KEY"
```

### Erro: "IP não autorizado" na Vega

- Confirme que adicionou o IP correto no painel Vega
- Verifique qual IP o VPS está usando: `curl ifconfig.me`

### SSL não funciona

```bash
# Verificar se certbot rodou
certbot certificates

# Tentar novamente
certbot --nginx -d seudominio.com -d www.seudominio.com
```

---

## 💰 Custos Estimados

| Item | Custo |
|------|-------|
| VPS (2GB RAM) | R$ 30-50/mês |
| Domínio .com.br | R$ 40/ano |
| SSL (Let's Encrypt) | Grátis |
| **Total** | **~R$ 35/mês** |

---

## ✅ Checklist de Go-Live

- [ ] VPS configurado e online
- [ ] Node.js e PM2 instalados
- [ ] Backend rodando com PM2
- [ ] Nginx configurado
- [ ] Domínio apontando para VPS
- [ ] SSL/HTTPS funcionando
- [ ] IP adicionado no painel Vega
- [ ] Webhook Vega configurado
- [ ] Teste de compra completo realizado
- [ ] Logs sendo monitorados
- [ ] Backup configurado

---

## 📞 Suporte

**Problemas com:**
- VPS: Suporte da TurboCloud/seu provedor
- Domínio: Suporte do Registro.br/seu registrador
- Vega: Suporte da Vega Checkout
- Código: Este projeto

---

## 🔄 Migração de VPS

Se precisar mudar de VPS:

1. Contratar novo VPS
2. Repetir passos de configuração
3. Fazer deploy
4. **IMPORTANTE:** Atualizar IP no painel Vega
5. Atualizar DNS para apontar para novo IP
6. Aguardar propagação DNS
7. Desativar VPS antigo

**Tempo estimado:** ~1 hora

---

## 🎉 Parabéns!

Seu e-commerce está rodando em produção com:
- ✅ Carrinho multi-produto
- ✅ Integração Vega Checkout
- ✅ IP fixo autorizado
- ✅ HTTPS seguro
- ✅ Infraestrutura profissional

**Boas vendas! 🚀**
