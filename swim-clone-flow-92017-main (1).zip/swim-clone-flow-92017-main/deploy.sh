#!/bin/bash

# ============================================
# Script de Deploy Automatizado
# Versiani Swim - Deploy Completo
# ============================================

set -e

# CONFIGURAÇÕES (EDITE AQUI!)
VPS_USER="appuser"
VPS_IP="SEU_IP_AQUI"
VPS_PATH="/home/appuser/versiani-app"
BACKEND_NAME="versiani-backend"
DOMAIN="seudominio.com.br"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Iniciando deploy da Versiani Swim...${NC}"

# 1. Build do Frontend
echo -e "${YELLOW}📦 Building frontend...${NC}"
npm run build

if [ ! -d "dist" ]; then
    echo -e "${RED}❌ Erro: pasta dist/ não foi gerada!${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Build concluído!${NC}"

# 2. Criar backup no VPS antes do deploy
echo -e "${YELLOW}💾 Criando backup no VPS...${NC}"
ssh ${VPS_USER}@${VPS_IP} << 'ENDSSH'
if [ -d /home/appuser/versiani-app/frontend ]; then
    tar -czf /home/appuser/backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /home/appuser/versiani-app frontend
    echo "✅ Backup criado"
fi
ENDSSH

# 3. Comprimir frontend
echo -e "${YELLOW}📦 Comprimindo arquivos...${NC}"
tar -czf frontend.tar.gz dist/

# 4. Upload para VPS
echo -e "${YELLOW}📤 Enviando para VPS...${NC}"
scp frontend.tar.gz ${VPS_USER}@${VPS_IP}:${VPS_PATH}/

# 5. Deploy no VPS
echo -e "${YELLOW}🔄 Executando deploy no VPS...${NC}"
ssh ${VPS_USER}@${VPS_IP} << ENDSSH
cd ${VPS_PATH}

# Remover frontend antigo
echo "🗑️  Removendo versão antiga..."
rm -rf frontend

# Descompactar nova versão
echo "📦 Descompactando nova versão..."
tar -xzf frontend.tar.gz
mv dist frontend

# Limpar
rm frontend.tar.gz

# Restart do backend
echo "🔄 Reiniciando backend..."
pm2 restart ${BACKEND_NAME}

# Status
pm2 status ${BACKEND_NAME}

echo "✅ Deploy concluído no VPS!"
ENDSSH

# 6. Limpar arquivos locais
rm frontend.tar.gz

# 7. Verificar se está funcionando
echo -e "${YELLOW}🔍 Verificando saúde da API...${NC}"
sleep 3
HEALTH_CHECK=$(ssh ${VPS_USER}@${VPS_IP} "curl -s http://localhost:3001/api/health")

if [[ $HEALTH_CHECK == *"ok"* ]]; then
    echo -e "${GREEN}✅ API está respondendo corretamente!${NC}"
else
    echo -e "${RED}⚠️  Aviso: API pode não estar respondendo corretamente${NC}"
fi

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✅ DEPLOY CONCLUÍDO COM SUCESSO!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "🌐 Site: https://seudominio.com"
echo -e "📊 Logs: ${YELLOW}ssh ${VPS_USER}@${VPS_IP} 'pm2 logs ${BACKEND_NAME}'${NC}"
echo -e "🔧 Restart: ${YELLOW}ssh ${VPS_USER}@${VPS_IP} 'pm2 restart ${BACKEND_NAME}'${NC}"
echo ""
