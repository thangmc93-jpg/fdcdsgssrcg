const express = require('express');
const router = express.Router();
const vegaService = require('../services/vega');

router.post('/create-checkout', async (req, res) => {
  try {
    const { cart, utmData } = req.body;
    
    if (!cart || !Array.isArray(cart) || cart.length === 0) {
      return res.status(400).json({ error: 'Carrinho vazio ou inválido' });
    }

    console.log(`📦 Criando checkout para ${cart.length} item(ns)`);
    
    // Calcular totais
    const subtotal = cart.reduce((sum, item) => 
      sum + (item.product.price * item.quantity), 0
    );
    const pixDiscount = subtotal * 0.10; // 10% desconto PIX
    const total = subtotal - pixDiscount;
    
    // Formatar produtos para Vega
    const produtos = cart.map(item => ({
      nome: item.product.name,
      quantidade: item.quantity,
      preco_unitario: item.product.price,
      preco_original: item.product.oldPrice,
      tamanho_top: item.selectedSize,
      tamanho_calcinha: item.selectedBottomSize || item.selectedSize,
      tipo: item.product.type,
      desconto: item.product.discount
    }));
    
    // Payload para Vega
    const vegaPayload = {
      produtos: produtos,
      valor_subtotal: subtotal.toFixed(2),
      valor_desconto_pix: pixDiscount.toFixed(2),
      valor_total: total.toFixed(2),
      utm_source: utmData?.source || 'direct',
      utm_medium: utmData?.medium || 'none',
      utm_campaign: utmData?.campaign || 'none',
      utm_content: utmData?.content || 'none',
      pixel: utmData?.pixel || '',
      quantidade_total: cart.reduce((sum, item) => sum + item.quantity, 0)
    };
    
    console.log('📤 Enviando para Vega:', JSON.stringify(vegaPayload, null, 2));
    
    // Chamar API Vega
    const checkoutUrl = await vegaService.createCheckout(vegaPayload);
    
    console.log('✅ Checkout criado com sucesso:', checkoutUrl);
    
    res.json({ 
      success: true,
      checkout_url: checkoutUrl,
      total: total.toFixed(2)
    });
    
  } catch (error) {
    console.error('❌ Erro ao criar checkout:', error.message);
    console.error('Stack:', error.stack);
    
    res.status(500).json({ 
      success: false,
      error: 'Erro ao criar checkout',
      message: process.env.NODE_ENV === 'development' ? error.message : 'Tente novamente'
    });
  }
});

module.exports = router;
