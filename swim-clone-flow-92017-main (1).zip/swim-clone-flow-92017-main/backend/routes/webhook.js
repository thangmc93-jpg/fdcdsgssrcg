const express = require('express');
const router = express.Router();

router.post('/vega-webhook', async (req, res) => {
  try {
    const webhookData = req.body;
    
    console.log('🔔 Webhook recebido da Vega:', JSON.stringify(webhookData, null, 2));
    
    const { 
      status, 
      order_id, 
      payment_info,
      customer_info,
      products,
      total_amount 
    } = webhookData;
    
    // Log detalhado do pagamento
    console.log('📊 Status do pagamento:', status);
    console.log('🆔 Order ID:', order_id);
    console.log('💰 Valor total:', total_amount);
    
    // Processar baseado no status
    switch (status) {
      case 'approved':
      case 'paid':
        console.log('✅ Pagamento aprovado!');
        // Aqui você pode:
        // - Salvar no banco de dados
        // - Enviar email de confirmação
        // - Atualizar estoque
        // - Notificar sistemas externos
        break;
        
      case 'pending':
        console.log('⏳ Pagamento pendente');
        break;
        
      case 'rejected':
      case 'cancelled':
        console.log('❌ Pagamento rejeitado/cancelado');
        break;
        
      default:
        console.log('ℹ️ Status desconhecido:', status);
    }
    
    // Responder para Vega confirmar recebimento
    res.json({ 
      success: true,
      received: true,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ Erro ao processar webhook:', error.message);
    console.error('Stack:', error.stack);
    
    // Mesmo com erro, responder 200 para não reenviar webhook
    res.status(200).json({ 
      success: false,
      received: true,
      error: error.message 
    });
  }
});

module.exports = router;
