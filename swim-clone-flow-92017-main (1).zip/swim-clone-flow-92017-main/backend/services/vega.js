const axios = require('axios');

class VegaService {
  constructor() {
    this.apiUrl = process.env.VEGA_API_URL;
    this.apiKey = process.env.VEGA_API_KEY;
    
    if (!this.apiUrl || !this.apiKey) {
      console.warn('⚠️ VEGA_API_URL ou VEGA_API_KEY não configurados!');
    }
  }

  async createCheckout(payload) {
    try {
      console.log('🔗 Chamando Vega API:', this.apiUrl);
      
      const response = await axios.post(
        `${this.apiUrl}/checkout/create`,
        payload,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000 // 30 segundos timeout
        }
      );
      
      if (!response.data || !response.data.checkout_url) {
        throw new Error('Resposta inválida da Vega API');
      }
      
      return response.data.checkout_url;
      
    } catch (error) {
      console.error('❌ Erro na chamada Vega API:');
      
      if (error.response) {
        // Erro de resposta da API
        console.error('Status:', error.response.status);
        console.error('Data:', error.response.data);
        throw new Error(`Vega API error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
      } else if (error.request) {
        // Requisição foi feita mas sem resposta
        console.error('Sem resposta da Vega API');
        throw new Error('Vega API não respondeu. Verifique a conexão.');
      } else {
        // Erro na configuração da requisição
        console.error('Erro:', error.message);
        throw error;
      }
    }
  }

  async validateWebhook(signature, payload) {
    // Implementar validação de assinatura do webhook se Vega fornecer
    // Por enquanto retorna true
    return true;
  }
}

module.exports = new VegaService();
