interface MarqueeBannerProps {
  text: string;
}

export const MarqueeBanner = ({ text }: MarqueeBannerProps) => {
  return (
    <div className="w-full overflow-hidden bg-gradient-to-r from-orange-600 to-red-600 py-2">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...Array(10)].map((_, i) => (
          <span key={i} className="text-white text-sm font-semibold mx-8">
            {text}
          </span>
        ))}
      </div>
    </div>
  );
};
