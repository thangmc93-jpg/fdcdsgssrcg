import heroBanner from '@/assets/hero-banner.png';

export const Hero = () => {
  return (
    <section className="relative w-full mt-14">
      <img 
        src={heroBanner} 
        alt="Black Friday - Até 85% OFF + Brindes Exclusivos" 
        className="w-full h-auto object-cover"
      />
    </section>
  );
};
