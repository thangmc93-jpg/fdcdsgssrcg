interface ColorSelectorProps {
  colors: Array<{ name: string; hex: string }>;
  selectedColor: string;
  onColorChange: (color: string) => void;
}

export const ColorSelector = ({ colors, selectedColor, onColorChange }: ColorSelectorProps) => {
  return (
    <div className="space-y-2 sm:space-y-3 w-full">
      <p className="text-xs sm:text-sm font-medium">Cor: <span className="font-semibold">{selectedColor}</span></p>
      <div className="flex gap-2 flex-wrap">
        {colors.map((color) => (
          <button
            key={color.name}
            onClick={() => onColorChange(color.name)}
            className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 transition-all ${
              selectedColor === color.name
                ? 'border-primary scale-110'
                : 'border-gray-300'
            }`}
            style={{ backgroundColor: color.hex }}
            aria-label={color.name}
          />
        ))}
      </div>
    </div>
  );
};
