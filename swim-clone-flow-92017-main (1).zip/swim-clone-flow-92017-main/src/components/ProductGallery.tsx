import { useState } from 'react';
import { Clock } from 'lucide-react';

interface ProductGalleryProps {
  images: string[];
  stockText: string;
  stockBadge: string;
}

export const ProductGallery = ({ images, stockText, stockBadge }: ProductGalleryProps) => {
  const [selectedImage, setSelectedImage] = useState(0);

  return (
    <div className="w-full">
      <div className="relative rounded-2xl overflow-hidden bg-gray-100 mb-4 w-full">
        <img
          src={images[selectedImage]}
          alt="Produto"
          className="w-full h-auto object-contain"
        />
        
        <div className="absolute top-2 sm:top-3 left-2 sm:left-3 bg-[#FFB7C7] text-black text-[10px] sm:text-xs font-medium px-2 sm:px-3 py-1 sm:py-1.5 rounded-full flex items-center gap-1 sm:gap-1.5 max-w-[calc(100%-4rem)]">
          <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 flex-shrink-0" />
          <span className="truncate">{stockText}</span>
        </div>
        
        <div className="absolute top-2 sm:top-3 right-2 sm:right-3 bg-[#FFB7C7] text-black text-[10px] sm:text-xs font-medium px-2 sm:px-3 py-1 sm:py-1.5 rounded-full">
          {stockBadge}
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide w-full">
        {images.map((image, index) => (
          <button
            key={index}
            onClick={() => setSelectedImage(index)}
            className={`flex-shrink-0 w-14 h-14 sm:w-16 sm:h-16 rounded-lg overflow-hidden border-2 transition-all ${
              selectedImage === index ? 'border-primary' : 'border-gray-200'
            }`}
          >
            <img src={image} alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
};
