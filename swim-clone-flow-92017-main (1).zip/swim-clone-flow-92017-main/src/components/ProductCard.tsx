import { Product } from '@/types/product';
import { ShoppingCart } from 'lucide-react';
import { formatPrice } from '@/utils/cart';

interface ProductCardProps {
  product: Product;
  onQuickAdd: (product: Product) => void;
  onClick: (product: Product) => void;
}

export const ProductCard = ({ product, onQuickAdd, onClick }: ProductCardProps) => {
  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Bloquear se o produto estiver esgotado
    if (product.soldOut) {
      return;
    }
    
    // Abrir modal para selecionar tamanho antes de adicionar
    onClick(product);
  };

  return (
    <div
      onClick={() => onClick(product)}
      className="cursor-pointer group"
    >
      <div className="relative shadow-card hover:shadow-elevated transition-all duration-300 rounded-lg overflow-hidden">
        <div
          className={`${
            product.soldOut 
              ? 'bg-slate-800' 
              : product.discount === '85%' 
                ? 'bg-orange-hot' 
                : 'bg-red-hot'
          } text-white font-bold text-[10px] md:text-sm py-1.5 md:py-2 overflow-hidden rounded-t-lg`}
        >
          <div className="animate-marquee whitespace-nowrap inline-block">
            {product.soldOut ? (
              <>PRODUTO ESGOTADO&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;PRODUTO FORA DE ESTOQUE&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;PRODUTO ESGOTADO&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;PRODUTO FORA DE ESTOQUE&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;</>
            ) : (
              <>ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;</>
            )}
          </div>
        </div>
        
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-64 md:h-80 object-cover group-hover:scale-105 transition-transform duration-300 rounded-b-lg"
        />
        
        <button
          onClick={handleQuickAdd}
          disabled={product.soldOut}
          className={`absolute bottom-3 right-3 bg-white p-3 rounded-full shadow-elevated transition-all duration-300 ${
            product.soldOut 
              ? 'opacity-50 cursor-not-allowed' 
              : 'hover:bg-yellow-cta hover:scale-110'
          }`}
          aria-label={product.soldOut ? 'Produto esgotado' : 'Adicionar ao carrinho'}
        >
          <ShoppingCart className="w-5 h-5" />
        </button>
      </div>
      
      <div className="pt-3 space-y-1">
        <h3 className="font-normal text-xs md:text-base line-clamp-2 text-foreground leading-tight">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-1.5 md:gap-2 flex-wrap">
          <span className="text-base md:text-xl font-semibold text-foreground">
            {formatPrice(product.price)}
          </span>
          <span className="bg-green-600 text-white text-[10px] md:text-xs font-bold px-2 py-0.5 rounded">
            -{Math.round((1 - product.price / product.oldPrice) * 100)}% OFF
          </span>
        </div>
        
        <p className="text-[11px] md:text-sm text-muted-foreground line-through">
          {formatPrice(product.oldPrice)}
        </p>
      </div>
    </div>
  );
};
