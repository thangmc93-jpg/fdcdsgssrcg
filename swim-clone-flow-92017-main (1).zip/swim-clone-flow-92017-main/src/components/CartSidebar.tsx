import { CartItem } from '@/types/product';
import { X, Plus, Minus } from 'lucide-react';
import { formatPrice, calculateSubtotal, calculatePixDiscount, calculateTotal } from '@/utils/cart';
import { UNIT_PRICE } from '@/config/vegaCheckoutLinks';
import { useEffect, useRef, useState } from 'react';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: () => void;
}

export const CartSidebar = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartSidebarProps) => {
  const subtotal = calculateSubtotal(cart);
  const pixDiscount = calculatePixDiscount(subtotal);
  const total = calculateTotal(cart);
  
  // Bônus configuration
  const BONUS_1 = 50;
  const BONUS_2 = 80;
  
  // Track previous subtotal to detect milestone achievements
  const prevSubtotalRef = useRef(subtotal);
  const [hasReached60, setHasReached60] = useState(false);
  const [hasReached90, setHasReached90] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  
  // Calculate progress percentage based on subtotal
  const calculateProgress = () => {
    if (subtotal >= BONUS_2) return 100;
    if (subtotal >= BONUS_1) {
      return 50 + ((subtotal - BONUS_1) / (BONUS_2 - BONUS_1)) * 50;
    }
    return (subtotal / BONUS_1) * 50;
  };
  
  const progressPercentage = calculateProgress();
  
  // Calculate remaining amount based on subtotal
  const getRemainingText = () => {
    if (subtotal >= BONUS_2) {
      return "Você desbloqueou os dois bônus!";
    }
    if (subtotal >= BONUS_1) {
      const remaining = BONUS_2 - subtotal;
      return `Adicione ${formatPrice(remaining)} para ganhar: Bônus Y.`;
    }
    const remaining = BONUS_1 - subtotal;
    return `Adicione ${formatPrice(remaining)} para ganhar: Bônus X.`;
  };
  
  // Detect milestone achievements based on subtotal
  useEffect(() => {
    const prevSubtotal = prevSubtotalRef.current;
    
    // Check if reached 60 for the first time
    if (subtotal >= BONUS_1 && prevSubtotal < BONUS_1 && !hasReached60) {
      setHasReached60(true);
    }
    
    // Check if reached 90 for the first time
    if (subtotal >= BONUS_2 && prevSubtotal < BONUS_2 && !hasReached90) {
      setHasReached90(true);
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 4000);
    }
    
    prevSubtotalRef.current = subtotal;
  }, [subtotal, hasReached60, hasReached90]);

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 z-40 animate-fade-in"
        onClick={onClose}
      />
      
      <div className="fixed right-0 top-0 bottom-0 w-full md:w-[450px] bg-white z-50 shadow-elevated animate-slide-in-right flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold">Carrinho</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary rounded-lg transition-colors"
            aria-label="Fechar carrinho"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overflow-x-hidden p-6 scrollbar-hide [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          {/* Confetti Animation */}
          {showConfetti && (
            <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
              {[...Array(50)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-2 h-2 animate-fade-in"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: '-10px',
                    backgroundColor: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'][i % 5],
                    animation: `confetti-fall ${2 + Math.random() * 2}s linear forwards`,
                    animationDelay: `${Math.random() * 0.5}s`,
                    transform: `rotate(${Math.random() * 360}deg)`,
                  }}
                />
              ))}
            </div>
          )}
          
          {/* Minimalist Bonus Progress Bar */}
          <div className="mb-8 px-1">
            {/* Status Text - Centered and Subtle */}
            <p className={`text-center text-xs font-medium mb-8 transition-colors duration-300 ${
              subtotal >= BONUS_2 
                ? 'text-green-600' 
                : subtotal >= BONUS_1 
                  ? 'text-blue-600'
                  : 'text-gray-600'
            }`}>
              {getRemainingText()}
            </p>
            
            {/* Progress Bar Container */}
            <div className="relative w-full h-1.5 bg-gray-200 rounded-full">
              {/* Filled Progress */}
              <div 
                className={`absolute h-full rounded-full transition-all duration-500 ease-out ${
                  subtotal >= BONUS_2 
                    ? 'bg-green-500' 
                    : subtotal >= BONUS_1
                      ? 'bg-green-500'
                      : 'bg-gray-400'
                } ${hasReached60 && subtotal >= BONUS_1 && subtotal < BONUS_2 ? 'animate-pulse' : ''}`}
                style={{ width: `${progressPercentage}%` }}
              />
              
              {/* Current Value Indicator (Small Dot) */}
              {progressPercentage > 0 && (
                <div 
                  className="absolute -top-5 transition-all duration-500 ease-out"
                  style={{ 
                    left: `${Math.min(progressPercentage, 100)}%`,
                    transform: 'translateX(-50%)'
                  }}
                >
                  <div className="bg-green-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full whitespace-nowrap shadow-sm">
                    {formatPrice(subtotal)}
                  </div>
                </div>
              )}
              
              {/* Milestone Markers */}
              {/* Marker at 50% (R$ 60) */}
              <div 
                className="absolute -top-0.5 w-2 h-2 rounded-full transition-colors duration-300"
                style={{ 
                  left: '50%', 
                  transform: 'translateX(-50%)',
                  backgroundColor: subtotal >= BONUS_1 ? '#10b981' : '#d1d5db'
                }}
              />
              
              {/* Marker at 100% (R$ 90) */}
              <div 
                className="absolute -top-0.5 w-2 h-2 rounded-full transition-colors duration-300"
                style={{ 
                  right: '0',
                  transform: 'translateX(50%)',
                  backgroundColor: subtotal >= BONUS_2 ? '#10b981' : '#d1d5db'
                }}
              />
            </div>
            
            {/* Milestone Labels */}
            <div className="relative w-full mt-1.5">
              <div 
                className="absolute text-[10px] font-medium text-gray-500"
                style={{ left: '50%', transform: 'translateX(-50%)' }}
              >
                {formatPrice(BONUS_1)}
              </div>
              <div 
                className="absolute text-[10px] font-medium text-gray-500"
                style={{ right: '0', transform: 'translateX(50%)' }}
              >
                {formatPrice(BONUS_2)}
              </div>
            </div>
            
            {/* Achievement Message */}
            {subtotal >= BONUS_2 && (
              <div className="mt-8 p-2.5 bg-green-50 border border-green-300 rounded-md animate-fade-in">
                <p className="text-green-700 font-semibold text-xs text-center">
                  🎉 Parabéns! Você conquistou 2 bônus que serão enviados junto à sua compra!
                </p>
              </div>
            )}
          </div>
          
          <style>{`
            @keyframes confetti-fall {
              0% {
                transform: translateY(0) rotate(0deg);
                opacity: 1;
              }
              100% {
                transform: translateY(100vh) rotate(720deg);
                opacity: 0;
              }
            }
          `}</style>

          {cart.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              Seu carrinho está vazio
            </div>
          ) : (
            <div className="space-y-4 overflow-hidden">
              {cart.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}-${item.selectedBottomSize || ''}`}
                  className="flex gap-3 p-4 bg-secondary rounded-lg relative overflow-hidden"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                  />
                  
                  <div className="flex-1 space-y-1 pr-16 min-w-0">
                    <h3 className="font-medium text-sm truncate">
                      {item.product.name}
                    </h3>
                    <p className="text-xs text-muted-foreground truncate">
                      {item.product.type === 'conjunto' 
                        ? `Top: ${item.selectedSize} / Calcinha: ${item.selectedBottomSize}`
                        : `Tamanho: ${item.selectedSize}`
                      }
                    </p>
                    <p className="font-bold text-base">
                      {formatPrice(UNIT_PRICE * item.quantity)}
                    </p>
                  </div>

                  <div className="absolute top-4 right-2 flex items-center gap-1 bg-white rounded-lg px-1.5 py-1 shadow-sm flex-shrink-0">
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                      className="hover:bg-secondary rounded transition-colors p-0.5"
                      aria-label="Diminuir quantidade"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-semibold w-5 text-center text-xs">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                      className="hover:bg-secondary rounded transition-colors p-0.5"
                      aria-label="Aumentar quantidade"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t p-6 space-y-4 bg-secondary/30">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-semibold">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Desconto Pix (10%):</span>
                <span className="font-semibold">-{formatPrice(pixDiscount)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold border-t pt-2">
                <span>Total:</span>
                <span>{formatPrice(total)}</span>
              </div>
            </div>

            <div className="bg-green-50 border border-green-500 rounded-lg p-3 text-sm">
              <p className="text-green-700 font-semibold">
                ✅ Cupom PIX10 aplicado com sucesso!
              </p>
              <p className="text-green-600 text-xs mt-1">
                🟢 Desconto Pix ativado
              </p>
            </div>

            <button
              onClick={onCheckout}
              className="w-full bg-blue-checkout hover:bg-blue-600 text-white font-bold py-4 rounded-lg transition-all"
            >
              Finalizar Compra
            </button>
          </div>
        )}
      </div>
    </>
  );
};
