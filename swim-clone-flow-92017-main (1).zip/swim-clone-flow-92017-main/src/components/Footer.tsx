import { Instagram, Phone, Mail } from 'lucide-react';
import footerBadges from '@/assets/footer-badges.png';

export const Footer = () => {
  return (
    <footer className="bg-black text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4">Sobre Nós</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              A Versiani Swim não é apenas uma marca de biquínis, somos o seu novo conceito preferido: BEACHWEAR DOWNTOWN.
            </p>
            <p className="text-gray-400 text-sm leading-relaxed mt-3">
              Priorizando sempre os melhores insumos, as cores de maior tendência, texturas inesquecíveis.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Contato</h3>
            <div className="space-y-3 text-sm">
              <a
                href="https://wa.me/553121300825"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4" />
                31 2130 0825
              </a>
              <a
                href="mailto:faleconosco@versianiswim.com.br"
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4" />
                faleconosco@versianiswim.com.br
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <Instagram className="w-4 h-4" />
                @versianiswim
              </a>
            </div>
          </div>

          <div>
            <img src={footerBadges} alt="Segurança e Pagamentos" className="w-full max-w-sm" />
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
          <p className="whitespace-nowrap">VERSIANI SWIM 2024 © Todos os direitos reservados</p>
        </div>
      </div>
    </footer>
  );
};
