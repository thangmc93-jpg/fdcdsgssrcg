import { Product, CartItem } from '@/types/product';
import { X, ShoppingCart, Zap } from 'lucide-react';
import { useState, useEffect } from 'react';
import { formatPrice } from '@/utils/cart';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from "@/components/ui/carousel";

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
  onBuyNow: (item: CartItem) => void;
}

export const ProductModal = ({ product, isOpen, onClose, onAddToCart, onBuyNow }: ProductModalProps) => {
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedBottomSize, setSelectedBottomSize] = useState('');
  const [selectedImage, setSelectedImage] = useState(0);
  const [api, setApi] = useState<CarouselApi>();
  
  // Verificar se o produto está esgotado
  const isSoldOut = product?.soldOut || false;

  useEffect(() => {
    if (!api) return;

    // Auto-advance carousel every 5 seconds
    const interval = setInterval(() => {
      if (api.canScrollNext()) {
        api.scrollNext();
      } else {
        api.scrollTo(0);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [api]);

  useEffect(() => {
    if (!api) return;

    api.on('select', () => {
      setSelectedImage(api.selectedScrollSnap());
    });
  }, [api]);

  if (!isOpen || !product) return null;

  const images = product.gallery || [product.image];

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Por favor, selecione o tamanho');
      return;
    }

    if (product.type === 'conjunto' && !selectedBottomSize) {
      alert('Por favor, selecione o tamanho da calcinha');
      return;
    }

    onAddToCart({
      product,
      quantity: 1,
      selectedSize,
      selectedBottomSize: product.type === 'conjunto' ? selectedBottomSize : undefined,
    });
    
    onClose();
  };

  const handleBuyNow = () => {
    if (!selectedSize) {
      alert('Por favor, selecione o tamanho');
      return;
    }

    if (product.type === 'conjunto' && !selectedBottomSize) {
      alert('Por favor, selecione o tamanho da calcinha');
      return;
    }

    onBuyNow({
      product,
      quantity: 1,
      selectedSize,
      selectedBottomSize: product.type === 'conjunto' ? selectedBottomSize : undefined,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 animate-fade-in p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto overflow-x-hidden animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center z-10">
          <h2 className="text-xl font-bold">{product.name}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary rounded-lg transition-colors"
            aria-label="Fechar"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 grid md:grid-cols-2 gap-8 overflow-hidden">
          <div className="space-y-4">
            <Carousel setApi={setApi} className="w-full">
              <CarouselContent>
                {images.map((img, index) => (
                  <CarouselItem key={index}>
                    <img
                      src={img}
                      alt={`${product.name} - ${index + 1}`}
                      className="w-full rounded-lg shadow-card"
                    />
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-2" />
              <CarouselNext className="right-2" />
            </Carousel>
            
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => api?.scrollTo(index)}
                    className={`flex-shrink-0 rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === index
                        ? 'border-foreground'
                        : 'border-border hover:border-foreground/50'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} - ${index + 1}`}
                      className="w-12 h-12 object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl font-bold">
                  {formatPrice(product.price)}
                </span>
                <span className="text-lg text-muted-foreground line-through">
                  {formatPrice(product.oldPrice)}
                </span>
              </div>
              <div className="inline-block bg-red-hot text-white font-bold px-4 py-2 rounded-lg">
                {product.discount} OFF
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-2">
                {product.type === 'conjunto' ? 'Tamanho do Top:' : product.type === 'top' ? 'Tamanho do Top:' : 'Tamanho da Calcinha:'}
              </label>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-4 py-2 rounded-lg border-2 transition-all ${
                      selectedSize === size
                        ? 'border-foreground bg-secondary'
                        : 'border-border hover:border-foreground'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {product.type === 'conjunto' && (
              <div>
                <label className="block font-semibold mb-2">Tamanho da Calcinha:</label>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedBottomSize(size)}
                      className={`px-4 py-2 rounded-lg border-2 transition-all ${
                        selectedBottomSize === size
                          ? 'border-foreground bg-secondary'
                          : 'border-border hover:border-foreground'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-3 pt-4">
              {isSoldOut ? (
                <button
                  disabled
                  className="w-full bg-gray-400 text-white font-bold py-4 rounded-lg cursor-not-allowed opacity-75"
                >
                  PRODUTO ESGOTADO
                </button>
              ) : (
                <>
                  <button
                    onClick={handleAddToCart}
                    className="w-full bg-foreground text-background hover:bg-foreground/90 font-bold py-4 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Adicionar ao Carrinho
                  </button>
                  
                  <button
                    onClick={handleBuyNow}
                    className="w-full bg-yellow-cta hover:bg-yellow-500 text-foreground font-bold py-4 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Zap className="w-5 h-5" />
                    Comprar Agora
                  </button>
                </>
              )}
            </div>

            {product.description && (
              <div className="pt-6 border-t">
                <h3 className="font-semibold mb-3 text-lg">Descrição</h3>
                <div className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                  {product.description}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
