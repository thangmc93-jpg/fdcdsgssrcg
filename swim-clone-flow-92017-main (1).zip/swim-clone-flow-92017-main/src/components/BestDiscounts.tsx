import { useNavigate } from 'react-router-dom';
import { products } from '@/data/products';
import { Star } from 'lucide-react';

export const BestDiscounts = () => {
  const navigate = useNavigate();
  
  // Get products 4-10 (indices 3-9) which are out of stock
  const soldOutProducts = products.slice(3, 10);

  const handleProductClick = () => {
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const calculateDiscount = (price: number, oldPrice: number) => {
    return Math.round((1 - price / oldPrice) * 100);
  };

  return (
    <div className="w-full bg-white px-4 sm:px-6 py-6 sm:py-8">
      <div className="flex items-center justify-between mb-6 sm:mb-8">
        <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-left">
          Melhores Descontos
        </h2>
        <button
          onClick={handleProductClick}
          className="flex items-center gap-1 text-sm sm:text-base font-medium text-foreground hover:opacity-70 transition-opacity"
        >
          Ver tudo
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-4 h-4"
          >
            <path d="m9 18 6-6-6-6" />
          </svg>
        </button>
      </div>
      
      <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
        {soldOutProducts.map((product) => {
          const discountPercent = calculateDiscount(product.price, product.oldPrice);
          
          return (
            <div
              key={product.id}
              onClick={handleProductClick}
              className="cursor-pointer group flex-shrink-0 w-48 sm:w-56 md:w-64"
            >
              <div className="relative shadow-card hover:shadow-elevated transition-all duration-300 rounded-lg overflow-hidden w-full">
                <div
                  className={`${
                    product.discount === '85%' ? 'bg-orange-hot' : 'bg-red-hot'
                  } text-white font-bold text-[10px] sm:text-xs md:text-sm py-1 sm:py-1.5 md:py-2 overflow-hidden rounded-t-lg relative`}
                >
                  <div className="flex animate-marquee-infinite whitespace-nowrap">
                    <span className="inline-block">
                      ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;
                    </span>
                    <span className="inline-block">
                      ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;
                    </span>
                    <span className="inline-block">
                      ESPECIAL BLACK {product.discount} OFF&nbsp;&nbsp;&nbsp;🔥&nbsp;&nbsp;&nbsp;
                    </span>
                  </div>
                </div>
                
                <div className="aspect-[3/4] w-full overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-white font-bold text-xs sm:text-sm md:text-base px-2 text-center">
                    Ver mais produtos
                  </span>
                </div>
              </div>
              
              <div className="pt-2 sm:pt-3 space-y-1 w-full">
                <h3 className="font-normal text-xs sm:text-sm md:text-base line-clamp-2 text-foreground leading-tight break-words">
                  {product.name}
                </h3>
                
                <div className="flex items-center gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className="w-3 h-3 sm:w-4 sm:h-4 fill-yellow-400 text-yellow-400" 
                    />
                  ))}
                </div>
                
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm sm:text-base md:text-lg font-bold text-foreground">
                    R$ {product.price.toFixed(2).replace('.', ',')}
                  </span>
                  <span className="text-[10px] sm:text-xs font-bold text-red-hot">
                    -{discountPercent}% OFF
                  </span>
                </div>
                
                <div className="text-xs sm:text-sm text-muted-foreground line-through">
                  R$ {product.oldPrice.toFixed(2).replace('.', ',')}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
