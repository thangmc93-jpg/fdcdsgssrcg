interface SizeChartRow {
  size: string;
  waist: string;
  hip: string;
}

interface SizeChartProps {
  data: SizeChartRow[];
  note?: string;
}

export const SizeChart = ({ data, note }: SizeChartProps) => {
  return (
    <div className="w-full space-y-4">
      <div className="overflow-x-auto rounded-lg border border-gray-200 w-full">
        <table className="w-full min-w-[300px]">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs sm:text-sm font-semibold whitespace-nowrap">Tamanho</th>
              <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs sm:text-sm font-semibold whitespace-nowrap">Cintura</th>
              <th className="px-3 sm:px-4 py-2 sm:py-3 text-left text-xs sm:text-sm font-semibold whitespace-nowrap">Quadril</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.map((row) => (
              <tr key={row.size} className="hover:bg-gray-50 transition-colors">
                <td className="px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm font-medium whitespace-nowrap">{row.size}</td>
                <td className="px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm whitespace-nowrap">{row.waist}</td>
                <td className="px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm whitespace-nowrap">{row.hip}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {note && (
        <p className="text-xs sm:text-sm text-gray-600 text-center px-2 break-words">
          {note}
        </p>
      )}
    </div>
  );
};
