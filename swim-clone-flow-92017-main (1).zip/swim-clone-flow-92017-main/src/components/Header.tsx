import { ShoppingCart } from 'lucide-react';
import { useEffect, useState } from 'react';

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export const Header = ({ cartCount, onCartClick }: HeaderProps) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 bg-white transition-all duration-300 w-full overflow-hidden ${
        isScrolled ? 'shadow-md' : ''
      }`}
    >
      <div className="w-full max-w-full px-3 sm:px-4 h-14 flex items-center justify-center relative">
        <h1 className="font-playfair text-xs sm:text-sm md:text-base font-light tracking-[0.2em] sm:tracking-[0.4em] text-center truncate">
          VERSIANI SWIM
        </h1>
        
        <button
          onClick={onCartClick}
          className="absolute right-3 sm:right-4 p-2 hover:bg-secondary/50 rounded-lg transition-colors flex-shrink-0"
          aria-label="Carrinho de compras"
        >
          <ShoppingCart className="w-5 h-5" strokeWidth={1.5} />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-hot text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
