import { Shield, Award, CheckCircle } from 'lucide-react';

export const TrustBadges = () => {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-white font-semibold mb-4">Segurança e qualidade</h3>
        <div className="flex justify-center items-center gap-6 flex-wrap">
          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2">
            <Shield className="w-6 h-6" />
            <span className="text-sm font-medium">Norton Secured</span>
          </div>
          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2">
            <Award className="w-6 h-6" />
            <span className="text-sm font-medium">ReclameAQUI</span>
          </div>
          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2">
            <CheckCircle className="w-6 h-6" />
            <span className="text-sm font-medium">Google Site Seguro</span>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-700 pt-6">
        <p className="text-center text-white text-sm mb-4">Nós aceitamos</p>
        <div className="flex justify-center items-center gap-4 flex-wrap">
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">AMEX</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">DINERS</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">DISCOVER</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">ELO</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">PIX</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">MASTERCARD</div>
          <div className="bg-white rounded px-3 py-2 text-xs font-bold">VISA</div>
        </div>
      </div>
    </div>
  );
};
