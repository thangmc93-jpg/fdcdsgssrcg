import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const faqs = [
  {
    question: 'Como funcionam os brindes progressivos?',
    answer: 'A cada valor de compra você ganha brindes exclusivos! Quanto mais você compra, mais brindes recebe. Os brindes são adicionados automaticamente ao seu pedido.',
  },
  {
    question: 'Como saber meu tamanho ideal?',
    answer: 'Temos um guia de tamanhos completo disponível em cada produto. Recomendamos medir suas medidas e comparar com nossa tabela para garantir o ajuste perfeito.',
  },
  {
    question: 'O tecido fica transparente ou marca o corpo?',
    answer: 'Nossos biquínis são confeccionados com tecido de alta qualidade, dupla face e com forro, garantindo que não fiquem transparentes nem marquem o corpo.',
  },
  {
    question: 'Como é o caimento das peças?',
    answer: 'Nossas peças têm modelagem brasileira e são projetadas para valorizar as curvas. O sistema de fitas permite ajuste personalizado para maior conforto e segurança.',
  },
  {
    question: 'O frete é grátis?',
    answer: 'Sim! Para compras acima de R$ 199,00 o frete é totalmente grátis para todo o Brasil. Para valores menores, o frete é calculado de acordo com sua região.',
  },
  {
    question: 'É seguro comprar na loja de vocês?',
    answer: 'Absolutamente! Nossa loja possui certificado SSL, selo Norton Secured, e somos bem avaliados no Reclame Aqui. Todos os pagamentos são processados de forma 100% segura.',
  },
  {
    question: 'Qual o prazo de entrega?',
    answer: 'O prazo varia de acordo com sua região, mas geralmente é de 5 a 15 dias úteis. Você recebe o código de rastreamento assim que o pedido é enviado.',
  },
  {
    question: 'Posso trocar ou devolver?',
    answer: 'Sim! Você tem 7 dias corridos a partir do recebimento para solicitar troca ou devolução, conforme o Código de Defesa do Consumidor. As peças devem estar sem uso e com etiquetas.',
  },
];

export const FAQ = () => {
  return (
    <section className="py-16 px-3 md:px-4 bg-background">
      <h2 className="text-2xl md:text-3xl font-normal text-center mb-8">
        Perguntas Frequentes
      </h2>
      
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem
            key={index}
            value={`item-${index}`}
            className="border-b border-border"
          >
            <AccordionTrigger className="text-left text-sm md:text-base font-normal hover:no-underline py-4">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-sm md:text-base text-muted-foreground pb-4">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
};
