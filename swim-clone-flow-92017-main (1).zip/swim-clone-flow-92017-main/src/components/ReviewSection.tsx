import { Star } from 'lucide-react';
import { useEffect, useState } from 'react';

interface ReviewSectionProps {
  overallRating: number;
  totalReviews: number;
  distribution: Array<{ stars: number; count: number }>;
}

const TESTIMONIALS = [
  {
    name: 'Luiza Monteiro',
    rating: 5,
    comment: 'Comprei e já chegou, muito rápida a entrega! Realmente fiquei surpresa com a qualidade, eu vi os comentários, estava esperando realmente que me agradasse, mas eu fiquei impressionada! Eu indico a compra!'
  },
  {
    name: 'Camila de Sousa',
    rating: 5,
    comment: 'Visto 48 e serviu perfeitamente, realmente valorizaram muito meu corpo, eu recomendo.'
  },
  {
    name: 'Juliana Mendes',
    rating: 5,
    comment: 'O pacote chegou em perfeito estado e antes do tempo de entrega estabelecido, qualidade e conforto surpreendentes, amei, indico a compra!'
  },
  {
    name: 'Brenda Freitas',
    rating: 5,
    comment: 'Vou ser bastante sincera, eu realmente não me lembro qual a última vez que vesti algo que me valorizasse tanto e fosse tão confortável, super indico!'
  },
  {
    name: 'Maria Paula',
    rating: 5,
    comment: 'Apenas experimentei, mas serviu certinho e acho que minha mãe também vai comprar pra ela ainda hoje pois o preço ta muito bom e chegou muito rápido.'
  },
  {
    name: 'Maria Fernanda',
    rating: 5,
    comment: 'Realmente sensacional, visto 54 e serviu certinho, não me apertou nem ficou largo, na medida perfeita!'
  },
  {
    name: 'Eliana Magalhães',
    rating: 5,
    comment: 'Muito bom, meu marido disse que me valorizaram muito, já estou pensando em comprar mais pra ser sincera.'
  },
  {
    name: 'Cristina Antunes',
    rating: 5,
    comment: 'Preço baixo e qualidade realmente existem! Vou comprar novamente para dar para minha irmã de natal, ela viu minhas peças e amou também.'
  },
  {
    name: 'Carol Montenegro',
    rating: 5,
    comment: 'Comprei pra minha mãe, ela gostou bastante, disse que é muito confortável e que vai indicar pra minha tia comprar também, se ela gostou é porque é bom mesmo, porque ela é bastante exigente.'
  },
  {
    name: 'Juliana Barros',
    rating: 5,
    comment: 'Difícil encontrar algo com um preço tão bom, confortável e com boa qualidade! Fiquei impressionada, eu recomendo.'
  }
];

const calculateDates = () => {
  // Obter data/hora atual do navegador
  const now = new Date();
  
  // Converter para horário de São Paulo (UTC-3)
  const saoPauloOffset = -3 * 60; // -3 horas em minutos
  const localOffset = now.getTimezoneOffset(); // offset local em minutos
  const diffMinutes = saoPauloOffset - localOffset;
  const saoPauloTime = new Date(now.getTime() + diffMinutes * 60 * 1000);
  
  // Verificar se já passou das 15h no horário de São Paulo
  const hour = saoPauloTime.getHours();
  
  // Se for antes das 15h, usar o dia anterior como referência base
  let baseDate = new Date(saoPauloTime);
  if (hour < 15) {
    baseDate.setDate(baseDate.getDate() - 1);
  }
  
  // Função para formatar data como DD/MM/YYYY
  const formatDate = (date: Date) => {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };
  
  // Calcular as três datas
  const today = new Date(baseDate);
  const yesterday = new Date(baseDate);
  yesterday.setDate(yesterday.getDate() - 1);
  const dayBeforeYesterday = new Date(baseDate);
  dayBeforeYesterday.setDate(dayBeforeYesterday.getDate() - 2);
  
  const dates: string[] = [];
  
  // 5 primeiros: hoje
  for (let i = 0; i < 5; i++) {
    dates.push(formatDate(today));
  }
  
  // 4 seguintes: ontem
  for (let i = 0; i < 4; i++) {
    dates.push(formatDate(yesterday));
  }
  
  // 3 últimos: anteontem
  for (let i = 0; i < 3; i++) {
    dates.push(formatDate(dayBeforeYesterday));
  }
  
  return dates;
};

export const ReviewSection = ({ overallRating, totalReviews, distribution }: ReviewSectionProps) => {
  const [dates, setDates] = useState<string[]>([]);
  const maxCount = Math.max(...distribution.map(d => d.count));

  useEffect(() => {
    // Calcular datas ao carregar o componente
    setDates(calculateDates());
    
    // Atualizar datas a cada minuto para capturar a mudança às 15h
    const interval = setInterval(() => {
      setDates(calculateDates());
    }, 60000); // 60 segundos
    
    return () => clearInterval(interval);
  }, []);

  // Combinar depoimentos com datas calculadas
  const reviewsWithDates = TESTIMONIALS.map((testimonial, index) => ({
    ...testimonial,
    date: dates[index] || '00/00/0000'
  }));

  return (
    <div className="space-y-6 sm:space-y-8 w-full">
      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-100 w-full">
        <div className="flex flex-col sm:flex-row items-start gap-4 sm:gap-8">
          <div className="text-center w-full sm:w-auto">
            <div className="text-4xl sm:text-5xl font-bold mb-2">{overallRating}</div>
            <div className="flex justify-center mb-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-[#FFD54F] text-[#FFD54F]" />
              ))}
            </div>
            <div className="text-xs sm:text-sm text-gray-600">{totalReviews} avaliações</div>
          </div>

          <div className="flex-1 space-y-2 w-full">
            {distribution.map((item) => (
              <div key={item.stars} className="flex items-center gap-2 sm:gap-3 w-full">
                <span className="text-xs sm:text-sm font-medium w-3 sm:w-4 flex-shrink-0">{item.stars}</span>
                <Star className="w-3 h-3 sm:w-4 sm:h-4 fill-[#FFD54F] text-[#FFD54F] flex-shrink-0" />
                <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden min-w-0">
                  <div
                    className="h-full bg-[#FFD54F]"
                    style={{ width: `${(item.count / maxCount) * 100}%` }}
                  />
                </div>
                <span className="text-xs sm:text-sm text-gray-600 w-8 sm:w-12 text-right flex-shrink-0">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-4 w-full">
        {reviewsWithDates.map((review, index) => (
          <div key={index} className="bg-white rounded-xl p-4 sm:p-5 shadow-sm border border-gray-100 w-full">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 gap-2">
              <h4 className="font-semibold text-sm sm:text-base">{review.name}</h4>
              <span className="text-xs sm:text-sm text-gray-500">{review.date}</span>
            </div>
            <div className="flex mb-3">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 sm:w-4 sm:h-4 ${
                    i < review.rating ? 'fill-[#FFD54F] text-[#FFD54F]' : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-gray-700 break-words">{review.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
