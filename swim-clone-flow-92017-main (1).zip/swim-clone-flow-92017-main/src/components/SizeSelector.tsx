interface SizeSelectorProps {
  sizes: string[];
  selectedSize: string;
  onSizeChange: (size: string) => void;
  label?: string;
}

export const SizeSelector = ({ sizes, selectedSize, onSizeChange, label = "Tamanho:" }: SizeSelectorProps) => {
  return (
    <div className="space-y-2 sm:space-y-3 w-full">
      <p className="text-xs sm:text-sm font-medium">{label} <span className="font-semibold">{selectedSize}</span></p>
      <div className="flex flex-wrap gap-2 w-full">
        {sizes.map((size) => (
          <button
            key={size}
            onClick={() => onSizeChange(size)}
            className={`w-10 h-10 sm:w-12 sm:h-12 border-2 rounded-lg font-medium text-sm sm:text-base transition-all ${
              selectedSize === size
                ? 'border-primary bg-primary text-white'
                : 'border-gray-300 hover:border-gray-400'
            }`}
          >
            {size}
          </button>
        ))}
      </div>
    </div>
  );
};
