import { CartItem } from '@/types/product';

declare global {
  interface Window {
    utmfyData: {
      source: string;
      medium: string;
      campaign: string;
      content: string;
    };
    trackUTMFY: (eventName: string, data: any) => void;
  }
}

export const trackAddToCart = (item: CartItem): void => {
  if (typeof window !== 'undefined' && window.trackUTMFY) {
    window.trackUTMFY('AddToCart', {
      product_name: item.product.name,
      product_id: item.product.id,
      price: item.product.price,
      quantity: item.quantity,
      size: item.selectedSize,
      bottom_size: item.selectedBottomSize,
    });
  }
};

export const trackInitiateCheckout = (cart: CartItem[], total: number): void => {
  if (typeof window !== 'undefined' && window.trackUTMFY) {
    window.trackUTMFY('InitiateCheckout', {
      num_items: cart.length,
      total_value: total,
      products: cart.map(item => ({
        name: item.product.name,
        id: item.product.id,
        quantity: item.quantity,
      })),
    });
  }
};

export const trackPurchase = (orderId: string, total: number): void => {
  if (typeof window !== 'undefined' && window.trackUTMFY) {
    window.trackUTMFY('Purchase', {
      order_id: orderId,
      value: total,
    });
  }
};

export const sendToVegaCheckout = async (cart: CartItem[], total: number): Promise<string> => {
  const { apiClient, API_CONFIG } = await import('@/config/api');
  
  // Get UTM parameters
  const utmData = window.utmfyData || {
    source: 'direct',
    medium: 'none',
    campaign: 'none',
    content: ''
  };

  try {
    console.log('🛒 Enviando carrinho para Vega Checkout...');
    
    const response = await apiClient.post(API_CONFIG.endpoints.createCheckout, {
      cart,
      utmData: {
        source: utmData.source,
        medium: utmData.medium,
        campaign: utmData.campaign,
        content: utmData.content,
        pixel: utmData.content
      }
    });

    if (!response.success || !response.checkout_url) {
      throw new Error('Resposta inválida do servidor');
    }

    console.log('✅ Checkout URL recebida:', response.checkout_url);
    return response.checkout_url;
    
  } catch (error) {
    console.error('❌ Erro ao criar checkout:', error);
    throw error;
  }
};
