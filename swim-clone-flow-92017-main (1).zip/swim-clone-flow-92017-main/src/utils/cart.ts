import { CartItem } from '@/types/product';
import { UNIT_PRICE } from '@/config/vegaCheckoutLinks';

const CART_STORAGE_KEY = 'versiani_cart';
const PIX_DISCOUNT = 0.10; // 10%

export const getCartFromStorage = (): CartItem[] => {
  try {
    const stored = localStorage.getItem(CART_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveCartToStorage = (cart: CartItem[]): void => {
  try {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  } catch (error) {
    console.error('Error saving cart:', error);
  }
};

export const calculateSubtotal = (cart: CartItem[]): number => {
  // Todos os produtos ativos têm preço fixo de R$29,90
  return cart.reduce((sum, item) => sum + (UNIT_PRICE * item.quantity), 0);
};

export const calculatePixDiscount = (subtotal: number): number => {
  return subtotal * PIX_DISCOUNT;
};

export const calculateTotal = (cart: CartItem[]): number => {
  const subtotal = calculateSubtotal(cart);
  const discount = calculatePixDiscount(subtotal);
  return subtotal - discount;
};

export const formatPrice = (price: number): string => {
  return price.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
};
