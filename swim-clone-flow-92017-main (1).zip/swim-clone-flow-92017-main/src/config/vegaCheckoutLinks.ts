// ⚠️ IMPORTANTE: SUBSTITUA OS LINKS ABAIXO PELOS LINKS REAIS DA VEGA CHECKOUT
// Cada quantidade (1 a 10) deve ter seu próprio link de checkout exclusivo

export const linksVegaPorQtd: Record<number, string> = {
  1: 'https://linkvega.com/checkout-1',
  2: 'https://linkvega.com/checkout-2',
  3: 'https://linkvega.com/checkout-3',
  4: 'https://linkvega.com/checkout-4',
  5: 'https://linkvega.com/checkout-5',
  6: 'https://linkvega.com/checkout-6',
  7: 'https://linkvega.com/checkout-7',
  8: 'https://linkvega.com/checkout-8',
  9: 'https://linkvega.com/checkout-9',
  10: 'https://linkvega.com/checkout-10',
};

// Preço unitário fixo para todos os produtos ativos (primeiros 3)
export const UNIT_PRICE = 29.90;

// Quantidade máxima permitida no carrinho
export const MAX_CART_QUANTITY = 10;
