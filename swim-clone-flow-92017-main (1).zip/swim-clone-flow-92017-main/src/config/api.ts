// Configuração da API Backend
// Esta URL será a do seu VPS após o deploy

export const API_CONFIG = {
  // DESENVOLVIMENTO: Use localhost para testes locais
  // PRODUÇÃO: Use o domínio do seu VPS
  baseURL: import.meta.env.VITE_API_URL || 'https://seudominio.com',
  
  endpoints: {
    createCheckout: '/api/create-checkout',
    health: '/api/health',
  },
  
  timeout: 30000, // 30 segundos
};

// Helper para fazer chamadas à API
export const apiClient = {
  async post(endpoint: string, data: any) {
    const url = `${API_CONFIG.baseURL}${endpoint}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    return response.json();
  },
  
  async get(endpoint: string) {
    const url = `${API_CONFIG.baseURL}${endpoint}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }
};
