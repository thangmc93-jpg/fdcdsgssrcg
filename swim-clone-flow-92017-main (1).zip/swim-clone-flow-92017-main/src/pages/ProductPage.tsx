import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/Header';
import { MarqueeBanner } from '@/components/MarqueeBanner';
import { ProductGallery } from '@/components/ProductGallery';
import { SizeSelector } from '@/components/SizeSelector';
import { ColorSelector } from '@/components/ColorSelector';
import { QuantitySelector } from '@/components/QuantitySelector';
import { SizeChart } from '@/components/SizeChart';
import { ReviewSection } from '@/components/ReviewSection';
import { BestDiscounts } from '@/components/BestDiscounts';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Star, Truck, Gift } from 'lucide-react';
import { CartItem } from '@/types/product';
import { getCartFromStorage, saveCartToStorage } from '@/utils/cart';
import { toast } from 'sonner';
import { products } from '@/data/products';
import { sendToVegaCheckout } from '@/utils/tracking';
export default function ProductPage() {
  const navigate = useNavigate();
  // Obter primeiro produto disponível
  const availableProducts = products.filter(p => !p.soldOut);
  const firstProduct = availableProducts[0];
  const [cart, setCart] = useState<CartItem[]>(getCartFromStorage());
  const [selectedSize, setSelectedSize] = useState(firstProduct?.topSizes?.[0] || firstProduct?.sizes[0] || 'P');
  const [selectedBottomSize, setSelectedBottomSize] = useState(firstProduct?.bottomSizes?.[0] || 'P');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Descrição personalizada da página (editável)
  const pageDescription = `A Calça Jeans Wide Leg Elegance Safira da BEIDÊ oferece uma combinação de estilo e conforto em uma modelagem moderna que realça a silhueta. Sua cintura alta e o caimento elegante criam um visual sofisticado e versátil para qualquer ocasião.

O detalhe de costura frontal alonga as pernas e adiciona charme à peça. A lavagem azul médio com pontos iluminados traz leveza e um toque contemporâneo, perfeita para compor looks estilosos com personalidade.`;
  const sizeChartData = [{
    size: '36',
    waist: '73 - 77',
    hip: '101 - 105'
  }, {
    size: '38',
    waist: '78 - 82',
    hip: '106 - 110'
  }, {
    size: '40',
    waist: '83 - 87',
    hip: '111 - 115'
  }, {
    size: '42',
    waist: '88 - 92',
    hip: '116 - 120'
  }, {
    size: '44',
    waist: '93 - 97',
    hip: '121 - 125'
  }, {
    size: '46',
    waist: '98 - 102',
    hip: '126 - 130'
  }, {
    size: '48',
    waist: '103 - 107',
    hip: '131 - 135'
  }, {
    size: '50',
    waist: '108 - 112',
    hip: '136 - 139'
  }, {
    size: '52',
    waist: '113 - 117',
    hip: '140 - 143'
  }, {
    size: '54',
    waist: '117 - 121',
    hip: '144 - 147'
  }];
  const reviewData = {
    overallRating: 4.9,
    totalReviews: 827,
    distribution: [{
      stars: 5,
      count: 783
    }, {
      stars: 4,
      count: 30
    }, {
      stars: 3,
      count: 14
    }, {
      stars: 2,
      count: 0
    }, {
      stars: 1,
      count: 0
    }]
  };
  const handleBuyNow = async () => {
    if (!firstProduct) return;
    
    const cartItem: CartItem = {
      product: firstProduct,
      quantity,
      selectedSize,
      selectedBottomSize: firstProduct.type === 'conjunto' ? selectedBottomSize : undefined
    };
    
    const tempCart = [cartItem];
    const total = firstProduct.price * quantity;
    
    try {
      toast.loading('Processando compra...');
      const checkoutUrl = await sendToVegaCheckout(tempCart, total);
      window.location.href = checkoutUrl;
    } catch (error) {
      toast.error('Erro ao processar compra. Tente novamente.');
      console.error('Erro no checkout:', error);
    }
  };
  return <div className="min-h-screen bg-background w-full overflow-x-hidden">
      <Header cartCount={cart.length} onCartClick={() => {}} />
      
      <div className="pt-14 w-full">
        <MarqueeBanner text="🔥 BLACK FRIDAY ATÉ 85% OFF 🔥 FRETE GRÁTIS SOMENTE HOJE" />

        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 mb-12">
          <div className="w-full">
            <ProductGallery images={firstProduct?.gallery || []} stockText="Restam apenas 13 unidades" stockBadge="Baixo estoque!" />
          </div>

          <div className="w-full space-y-4 sm:space-y-6">
            <div className="w-full">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-3 break-words">{firstProduct?.name}</h1>
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-[#FFD54F] text-[#FFD54F]" />)}
                </div>
                <span className="text-xs sm:text-sm text-gray-600">827 Avaliações</span>
              </div>
            </div>

            <div className="space-y-2 w-full">
              <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                <span className="text-base sm:text-lg text-gray-500 line-through">
                  R$ {firstProduct?.oldPrice.toFixed(2)}
                </span>
                <span className="bg-[#16C79A] text-white text-xs sm:text-sm font-bold px-2 py-1 rounded">
                  {firstProduct?.discount}
                </span>
              </div>
              <div className="text-2xl sm:text-3xl lg:text-4xl font-bold">
                R$ {firstProduct?.price.toFixed(2).replace('.', ',')}
              </div>
              <p className="text-xs sm:text-sm text-gray-600">
                Em até 6x sem juros
              </p>
            </div>

            {firstProduct?.type === 'conjunto' ? (
              <>
                <SizeSelector 
                  sizes={firstProduct?.topSizes || firstProduct?.sizes || []} 
                  selectedSize={selectedSize} 
                  onSizeChange={setSelectedSize}
                  label="Tamanho do Top:"
                />
                <SizeSelector 
                  sizes={firstProduct?.bottomSizes || firstProduct?.sizes || []} 
                  selectedSize={selectedBottomSize} 
                  onSizeChange={setSelectedBottomSize}
                  label="Tamanho da Calcinha:"
                />
              </>
            ) : (
              <SizeSelector 
                sizes={firstProduct?.sizes || []} 
                selectedSize={selectedSize} 
                onSizeChange={setSelectedSize} 
              />
            )}

              <div className="flex items-center gap-2 sm:gap-3 flex-wrap w-full">
                <div className="flex-shrink-0">
                  <QuantitySelector quantity={quantity} onQuantityChange={setQuantity} />
                </div>
                <Button onClick={handleBuyNow} className="flex-1 min-w-[180px] h-12 sm:h-14 text-base sm:text-lg font-bold bg-[#16C79A] hover:bg-[#0F9C74] text-white rounded-full">
                  COMPRAR AGORA
                </Button>
              </div>

              <div className="space-y-3 w-full">
                <div className="bg-[#E3FFF5] rounded-xl p-3 sm:p-4 flex gap-2 sm:gap-3 w-full">
                  <Truck className="w-5 h-5 sm:w-6 sm:h-6 text-[#16C79A] flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm sm:text-base text-[#0F9C74] mb-1">Envio Full</h4>
                    <p className="text-xs sm:text-sm text-gray-700 break-words">
                      Enviamos para todo o Brasil através dos correios, oferecendo agilidade, cuidado e qualidade em cada envio, garantindo que seus produtos cheguem até você com total segurança
                    </p>
                  </div>
                </div>

                <div className="bg-[#E3FFF5] rounded-xl p-3 sm:p-4 flex gap-2 sm:gap-3 w-full">
                  <Gift className="w-5 h-5 sm:w-6 sm:h-6 text-[#16C79A] flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm sm:text-base text-[#0F9C74] mb-1">BRINDES</h4>
                    <p className="text-xs sm:text-sm text-gray-700 break-words">
                      Garanta brindes exclusivos enviados pela nossa equipe como forma de agradecimento para te proporcionar uma experiência ainda mais especial.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8 sm:space-y-12 w-full">
            <div className="w-full">
              <h2 className="text-lg sm:text-xl font-bold mb-4">Tabela de Medidas</h2>
              <div className="w-full overflow-x-auto">
                <SizeChart data={sizeChartData} note="Todas as medidas acima estão em centímetros. Recomendamos comprar o tamanho que usa normalmente." />
              </div>
            </div>

            <div className="bg-black text-white py-3 sm:py-4 px-4 sm:px-6 rounded-lg w-full">
              <h2 className="text-xl sm:text-2xl font-bold text-center">DESCRIÇÃO</h2>
            </div>
            <div className="w-full">
              <p className="text-sm sm:text-base text-gray-700 whitespace-pre-line leading-relaxed break-words">
                {pageDescription}
              </p>
            </div>


            <div className="w-full">
              <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Avaliações</h2>
              <ReviewSection {...reviewData} />
            </div>
          </div>
        </div>
      </div>

      <BestDiscounts />
      
      <Footer />
    </div>;
}