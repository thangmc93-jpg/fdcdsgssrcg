import { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { ProductCard } from '@/components/ProductCard';
import { ProductModal } from '@/components/ProductModal';
import { CartSidebar } from '@/components/CartSidebar';
import { FAQ } from '@/components/FAQ';
import { Footer } from '@/components/Footer';
import { products } from '@/data/products';
import { Product, CartItem } from '@/types/product';
import { getCartFromStorage, saveCartToStorage } from '@/utils/cart';
import { trackAddToCart, trackInitiateCheckout } from '@/utils/tracking';
import { toast } from '@/hooks/use-toast';
import { linksVegaPorQtd, MAX_CART_QUANTITY, UNIT_PRICE } from '@/config/vegaCheckoutLinks';

const Index = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const storedCart = getCartFromStorage();
    setCart(storedCart);
  }, []);

  useEffect(() => {
    saveCartToStorage(cart);
  }, [cart]);

  const handleQuickAddToCart = (product: Product) => {
    // Verificar se o produto está esgotado (não é um dos 3 primeiros)
    const productIndex = products.findIndex(p => p.id === product.id);
    if (productIndex > 2) {
      toast({
        title: 'Produto esgotado',
        description: 'Este produto está esgotado.',
        variant: 'destructive',
      });
      return;
    }

    // Calcular quantidade total atual no carrinho
    const currentTotal = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    // Verificar se adicionar 1 unidade ultrapassa o limite
    if (currentTotal >= MAX_CART_QUANTITY) {
      toast({
        title: 'Limite atingido',
        description: 'No momento só trabalhamos com até 10 unidades por pedido.',
        variant: 'destructive',
      });
      return;
    }

    const newItem: CartItem = {
      product,
      quantity: 1,
      selectedSize: product.sizes[0],
      selectedBottomSize: product.type === 'conjunto' ? product.sizes[0] : undefined,
    };

    const existingItemIndex = cart.findIndex(
      (item) =>
        item.product.id === product.id &&
        item.selectedSize === newItem.selectedSize &&
        item.selectedBottomSize === newItem.selectedBottomSize
    );

    if (existingItemIndex > -1) {
      const updatedCart = [...cart];
      updatedCart[existingItemIndex].quantity += 1;
      setCart(updatedCart);
    } else {
      setCart([...cart, newItem]);
    }

    trackAddToCart(newItem);
    
    toast({
      title: 'Adicionado ao carrinho! 🛒',
      description: product.name,
    });
  };

  const handleAddToCart = (item: CartItem) => {
    // Verificar se o produto está esgotado (não é um dos 3 primeiros)
    const productIndex = products.findIndex(p => p.id === item.product.id);
    if (productIndex > 2) {
      toast({
        title: 'Produto esgotado',
        description: 'Este produto está esgotado.',
        variant: 'destructive',
      });
      return;
    }

    // Calcular quantidade total atual no carrinho
    const currentTotal = cart.reduce((sum, cartItem) => sum + cartItem.quantity, 0);
    
    // Verificar se adicionar a nova quantidade ultrapassa o limite
    if (currentTotal + item.quantity > MAX_CART_QUANTITY) {
      toast({
        title: 'Limite atingido',
        description: 'No momento só trabalhamos com até 10 unidades por pedido.',
        variant: 'destructive',
      });
      return;
    }

    const existingItemIndex = cart.findIndex(
      (cartItem) =>
        cartItem.product.id === item.product.id &&
        cartItem.selectedSize === item.selectedSize &&
        cartItem.selectedBottomSize === item.selectedBottomSize
    );

    if (existingItemIndex > -1) {
      const updatedCart = [...cart];
      updatedCart[existingItemIndex].quantity += item.quantity;
      setCart(updatedCart);
    } else {
      setCart([...cart, item]);
    }

    trackAddToCart(item);
    
    toast({
      title: 'Adicionado ao carrinho! 🛒',
      description: item.product.name,
    });
  };

  const handleBuyNow = (item: CartItem) => {
    handleAddToCart(item);
    setIsModalOpen(false);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(productId);
      return;
    }

    // Calcular quantidade total excluindo o item atual
    const totalOthers = cart
      .filter(item => item.product.id !== productId)
      .reduce((sum, item) => sum + item.quantity, 0);
    
    // Verificar se a nova quantidade total ultrapassa o limite
    if (totalOthers + newQuantity > MAX_CART_QUANTITY) {
      toast({
        title: 'Limite atingido',
        description: 'No momento só trabalhamos com até 10 unidades por pedido.',
        variant: 'destructive',
      });
      return;
    }

    const updatedCart = cart.map((item) =>
      item.product.id === productId ? { ...item, quantity: newQuantity } : item
    );
    setCart(updatedCart);
  };

  const handleRemoveItem = (productId: string) => {
    const updatedCart = cart.filter((item) => item.product.id !== productId);
    setCart(updatedCart);
    
    toast({
      title: 'Item removido',
      description: 'Produto removido do carrinho',
    });
  };

  const handleCheckout = () => {
    // Calcular quantidade total de itens no carrinho
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    // Validações
    if (totalItems === 0) {
      toast({
        title: 'Carrinho vazio',
        description: 'Seu carrinho está vazio.',
        variant: 'destructive',
      });
      return;
    }

    if (totalItems > MAX_CART_QUANTITY) {
      toast({
        title: 'Limite excedido',
        description: 'No momento só trabalhamos com até 10 unidades por pedido.',
        variant: 'destructive',
      });
      return;
    }

    // Buscar link do checkout Vega correspondente à quantidade
    const checkoutUrl = linksVegaPorQtd[totalItems];
    
    if (!checkoutUrl) {
      toast({
        title: 'Erro',
        description: 'Não foi possível encontrar o checkout para essa quantidade.',
        variant: 'destructive',
      });
      return;
    }

    // Calcular total para tracking (preço fixo de R$29,90 por unidade)
    const total = totalItems * UNIT_PRICE;
    trackInitiateCheckout(cart, total);
    
    // Redirecionar para Vega Checkout externo
    window.location.href = checkoutUrl;
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-background">
      <Header cartCount={totalItems} onCartClick={() => setIsCartOpen(true)} />
      
      <Hero />

      <section id="products" className="py-8 md:py-16 px-3 md:px-4">
        <h2 className="text-xl md:text-2xl lg:text-3xl font-normal text-center mb-8 md:mb-12 uppercase whitespace-nowrap">
          PRODUTOS COM MAIS DESCONTOS
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4 lg:gap-6 max-w-full">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickAdd={handleQuickAddToCart}
                onClick={handleProductClick}
              />
            ))}
        </div>
      </section>

      <FAQ />
      
      <Footer />

      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProduct(null);
        }}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />

      <CartSidebar
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />
    </div>
  );
};

export default Index;
