import { useState, useEffect } from 'react';

const INITIAL_TIME = 2 * 60 * 60 + 14 * 60 + 55; // 2h 14m 55s em segundos

export const useCountdown = () => {
  const [timeLeft, setTimeLeft] = useState(INITIAL_TIME);
  const [isPulsing, setIsPulsing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          return INITIAL_TIME; // Reinicia automaticamente
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const pulseInterval = setInterval(() => {
      setIsPulsing(true);
      setTimeout(() => setIsPulsing(false), 1000);
    }, 10000); // Pulse a cada 10 segundos

    return () => clearInterval(pulseInterval);
  }, []);

  const hours = Math.floor(timeLeft / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;

  const formatted = `${hours}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;

  return { formatted, isPulsing, isExpired: timeLeft === 0 };
};
