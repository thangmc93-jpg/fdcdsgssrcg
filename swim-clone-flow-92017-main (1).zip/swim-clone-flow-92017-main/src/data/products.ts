import { Product } from '@/types/product';
import kitFitaPreto1 from '@/assets/products/kit-fita-preto-1.webp';
import kitFitaPreto2 from '@/assets/products/kit-fita-preto-2.webp';
import kitFitaPreto3 from '@/assets/products/kit-fita-preto-3.webp';
import kitFitaPreto4 from '@/assets/products/kit-fita-preto-4.webp';
import kitFitaPreto5 from '@/assets/products/kit-fita-preto-5.webp';
import kitFitaPreto6 from '@/assets/products/kit-fita-preto-6.webp';
import kitFitaPreto7 from '@/assets/products/kit-fita-preto-7.webp';
import kitFitaPreto8 from '@/assets/products/kit-fita-preto-8.webp';
import kitFitaPreto9 from '@/assets/products/kit-fita-preto-9.webp';
import topFitaCinza1 from '@/assets/products/top-fita-cinza-1.webp';
import topFitaCinza2 from '@/assets/products/top-fita-cinza-2.webp';
import topFitaCinza3 from '@/assets/products/top-fita-cinza-3.webp';
import topFitaCinza4 from '@/assets/products/top-fita-cinza-4.webp';
import topFitaCinza5 from '@/assets/products/top-fita-cinza-5.webp';
import topFitaCinza6 from '@/assets/products/top-fita-cinza-6.webp';
import topFitaCinza7 from '@/assets/products/top-fita-cinza-7.webp';
import topFitaCinza8 from '@/assets/products/top-fita-cinza-8.webp';
import topFitaCinzaTabela from '@/assets/products/top-fita-cinza-tabela.webp';
import topFitaVanilla1 from '@/assets/products/top-fita-vanilla-1.webp';
import topFitaVanilla2 from '@/assets/products/top-fita-vanilla-2.webp';
import topFitaVanilla3 from '@/assets/products/top-fita-vanilla-3.webp';
import topFitaVanilla4 from '@/assets/products/top-fita-vanilla-4.webp';
import topFitaVanilla5 from '@/assets/products/top-fita-vanilla-5.webp';
import topFitaVanilla6 from '@/assets/products/top-fita-vanilla-6.webp';
import topFitaVanilla7 from '@/assets/products/top-fita-vanilla-7.webp';
import topFitaVanilla8 from '@/assets/products/top-fita-vanilla-8.webp';
import topFitaVanilla9 from '@/assets/products/top-fita-vanilla-9.webp';
import topFitaVermelho1 from '@/assets/products/top-fita-vermelho-1.webp';
import topFitaVermelho2 from '@/assets/products/top-fita-vermelho-2.webp';
import topFitaVermelho3 from '@/assets/products/top-fita-vermelho-3.webp';
import topFitaVermelho4 from '@/assets/products/top-fita-vermelho-4.webp';
import topFitaVermelho5 from '@/assets/products/top-fita-vermelho-5.webp';
import topFitaVermelho6 from '@/assets/products/top-fita-vermelho-6.webp';
import topFitaVermelho7 from '@/assets/products/top-fita-vermelho-7.webp';
import topFitaVermelho8 from '@/assets/products/top-fita-vermelho-8.webp';
import topFitaVermelho9 from '@/assets/products/top-fita-vermelho-9.webp';
import topFitaFlash1 from '@/assets/products/top-fita-flash-1.webp';
import topFitaFlash2 from '@/assets/products/top-fita-flash-2.webp';
import topFitaFlash3 from '@/assets/products/top-fita-flash-3.webp';
import topFitaFlash4 from '@/assets/products/top-fita-flash-4.webp';
import topFitaFlash5 from '@/assets/products/top-fita-flash-5.webp';
import topFitaFlash6 from '@/assets/products/top-fita-flash-6.webp';
import topFitaFlash7 from '@/assets/products/top-fita-flash-7.webp';
import topFitaFlashTabela from '@/assets/products/top-fita-flash-tabela.webp';
import topFitaEnseada1 from '@/assets/products/top-fita-enseada-1.webp';
import topFitaEnseada2 from '@/assets/products/top-fita-enseada-2.webp';
import topFitaEnseada3 from '@/assets/products/top-fita-enseada-3.webp';
import topFitaEnseada4 from '@/assets/products/top-fita-enseada-4.webp';
import topFitaEnseada5 from '@/assets/products/top-fita-enseada-5.webp';
import topFitaEnseada6 from '@/assets/products/top-fita-enseada-6.webp';
import topFitaEnseada7 from '@/assets/products/top-fita-enseada-7.webp';
import topFitaEnseada8 from '@/assets/products/top-fita-enseada-8.webp';
import topFitaPreto1 from '@/assets/products/top-fita-preto-1.webp';
import topFitaPreto2 from '@/assets/products/top-fita-preto-2.webp';
import topFitaPreto3 from '@/assets/products/top-fita-preto-3.webp';
import topFitaPreto4 from '@/assets/products/top-fita-preto-4.webp';
import topFitaPreto5 from '@/assets/products/top-fita-preto-5.webp';
import topFitaPreto6 from '@/assets/products/top-fita-preto-6.webp';
import calcinhaFitaPreto1 from '@/assets/products/calcinha-fita-preto-1.webp';
import calcinhaFitaPreto2 from '@/assets/products/calcinha-fita-preto-2.webp';
import calcinhaFitaPreto3 from '@/assets/products/calcinha-fita-preto-3.webp';
import calcinhaFitaPreto4 from '@/assets/products/calcinha-fita-preto-4.webp';
import calcinhaFitaPreto5 from '@/assets/products/calcinha-fita-preto-5.webp';
import calcinhaFitaPreto6 from '@/assets/products/calcinha-fita-preto-6.webp';
import calcinhaFitaPretoTabela from '@/assets/products/calcinha-fita-preto-tabela.webp';
import topFitaFrais1 from '@/assets/products/top-fita-frais-1.webp';
import topFitaFrais2 from '@/assets/products/top-fita-frais-2.webp';
import topFitaFrais3 from '@/assets/products/top-fita-frais-3.webp';
import topFitaFrais4 from '@/assets/products/top-fita-frais-4.webp';
import topFitaFrais5 from '@/assets/products/top-fita-frais-5.webp';
import topFitaFrais6 from '@/assets/products/top-fita-frais-6.webp';
import topFitaFrais7 from '@/assets/products/top-fita-frais-7.webp';
import topFitaFraisTabela from '@/assets/products/top-fita-frais-tabela.webp';
import calcinhaFitaFrais1 from '@/assets/products/calcinha-fita-frais-1.webp';
import calcinhaFitaFrais2 from '@/assets/products/calcinha-fita-frais-2.webp';
import calcinhaFitaFrais3 from '@/assets/products/calcinha-fita-frais-3.webp';
import calcinhaFitaFrais4 from '@/assets/products/calcinha-fita-frais-4.webp';
import calcinhaFitaFrais5 from '@/assets/products/calcinha-fita-frais-5.webp';
import calcinhaFitaFrais6 from '@/assets/products/calcinha-fita-frais-6.webp';
import calcinhaFitaFrais7 from '@/assets/products/calcinha-fita-frais-7.webp';
import calcinhaFitaFrais8 from '@/assets/products/calcinha-fita-frais-8.webp';
import calcinhaFitaFraisTabela from '@/assets/products/calcinha-fita-frais-tabela.webp';

export const products: Product[] = [
  {
    id: '1',
    name: 'Conjunto Fita Preto',
    price: 69.90,
    oldPrice: 196.00,
    image: kitFitaPreto1,
    gallery: [
      kitFitaPreto1,
      kitFitaPreto2,
      kitFitaPreto3,
      kitFitaPreto4,
      kitFitaPreto5,
      kitFitaPreto6,
      kitFitaPreto7,
      kitFitaPreto8,
      kitFitaPreto9,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    topSizes: ['P', 'M', 'G'],
    bottomSizes: ['P', 'M', 'G'],
    type: 'conjunto',
    description: `Conforto extremo, proteção solar e a marquinha perfeita

Feito com poliamida e elastano, o Top Fita Preto tem toque macio, alta elasticidade e secagem rápida. Resistente ao desbotamento, ataques de micro-organismos e com proteção UV, ele é a escolha certa para curtir o verão com segurança, durabilidade e muito estilo.

O top perfeito para o verão e para a marquinha dos sonhos

O Top Fita Preto é o favorito de quem entende de verão. Com tecido leve e elástico, seca rápido, não desbota e ainda protege a pele com tecnologia UV. Resistente, durável e macio, ele une conforto e sensualidade com estilo — da praia ao feed.`,
  },
  {
    id: '2',
    name: 'Conjunto Fita Cinza Gris',
    price: 69.90,
    oldPrice: 184.00,
    image: topFitaCinza1,
    gallery: [
      topFitaCinza1,
      topFitaCinza2,
      topFitaCinza3,
      topFitaCinza4,
      topFitaCinza5,
      topFitaCinza6,
      topFitaCinza7,
      topFitaCinza8,
      topFitaCinzaTabela,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'conjunto',
    description: `O Conjunto Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.
Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microganismos;

- Proteção Ultra Violeta: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.`,
  },
  {
    id: '3',
    name: 'Conjunto Top Fita Vanilla + Calcinha Fita Vanilla',
    price: 69.90,
    oldPrice: 218.00,
    image: topFitaVanilla1,
    gallery: [
      topFitaVanilla1,
      topFitaVanilla2,
      topFitaVanilla3,
      topFitaVanilla4,
      topFitaVanilla5,
      topFitaVanilla6,
      topFitaVanilla7,
      topFitaVanilla8,
      topFitaVanilla9,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'conjunto',
    description: `Conjunto Top Fita Vanilla + Calcinha Fita Vanilla
O Conjunto Top Fita Vanilla + Calcinha Fita Vanilla é o clássico essencial da Versiani Swim — atemporal, confortável e pensado para quem ama a marquinha perfeita do verão. Com design liso e sem amarrações, o conjunto se adapta naturalmente ao corpo, oferecendo ajuste impecável, toque macio e uma estética clean que valoriza a silhueta com sutileza e elegância.

O Top Fita Vanilla é leve, funcional e ideal para quem busca praticidade sem abrir mão do estilo. Seu tecido tecnológico de poliamida com elastano garante conforto elástico, secagem rápida e resistência ao desgaste, além de proteção UV+50 e pingente VS banhado a ouro 18k, que adiciona um toque de sofisticação discreta.

A Calcinha Fita Vanilla completa o conjunto com o mesmo design clean e confortável, oferecendo modelagem anatômica, toque suave e ajuste perfeito. Assim como o top, é confeccionada em tecido de alta durabilidade, com proteção solar, secagem rápida e resistência ao sol e às lavagens, mantendo a cor e o conforto por muito mais tempo.

Conjunto ideal para o verão — leve, sofisticado e feito para durar.
Tecido tecnológico com proteção UV+50 e pingente VS banhado a ouro 18k.`,
  },
  {
    id: '4',
    name: 'Conjunto Top Fita Vermelho Rubi + Calcinha Fita Vermelho Rubi',
    price: 64.90,
    oldPrice: 196.00,
    image: topFitaVermelho1,
    gallery: [
      topFitaVermelho1,
      topFitaVermelho2,
      topFitaVermelho3,
      topFitaVermelho4,
      topFitaVermelho5,
      topFitaVermelho6,
      topFitaVermelho7,
      topFitaVermelho8,
      topFitaVermelho9,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'conjunto',
    soldOut: true,
    description: `Conjunto Top Fita Vermelho Rubi + Calcinha Fita Vermelho Rubi
O Conjunto Top Fita Vermelho Rubi + Calcinha Fita Vermelho Rubi é o clássico absoluto da Versiani Swim — atemporal, confortável e feito para quem busca a marquinha perfeita do verão. Com design liso, sem amarrações e acabamento impecável, o conjunto une praticidade e elegância em um visual minimalista e vibrante.

O Top Fita Vermelho Rubi oferece ajuste natural ao corpo, toque super macio e sustentação leve, ideal para dias de sol e mergulhos. Confeccionado em tecido tecnológico de poliamida com elastano, garante secagem rápida, alta durabilidade e proteção UV+50, mantendo o conforto e a cor intensa mesmo após o uso contínuo. O detalhe do pingente VS banhado a ouro 18k adiciona um toque de sofisticação sutil e exclusivo.

A Calcinha Fita Vermelho Rubi acompanha o mesmo conceito de conforto e praticidade, com modelagem lisa e anatômica que se adapta perfeitamente ao corpo. Seu tecido elástico e resistente proporciona liberdade de movimento, toque sedoso e secagem rápida, além de manter a proteção solar UV+50 e resistência ao desbotamento, mesmo após muitas lavagens.

Conjunto essencial para o verão — vibrante, confortável e com toque luxuoso.
Tecido tecnológico com proteção UV+50 e pingente VS banhado a ouro 18k.`,
  },
  {
    id: '5',
    name: 'Conjunto Fita Flash',
    price: 64.90,
    oldPrice: 156.00,
    image: topFitaFlash1,
    gallery: [
      topFitaFlash1,
      topFitaFlash2,
      topFitaFlash3,
      topFitaFlash4,
      topFitaFlash5,
      topFitaFlash6,
      topFitaFlash7,
      topFitaFlashTabela,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'conjunto',
    soldOut: true,
    description: `O Conjunto Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.
Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microganismos;

- Proteção Ultra Violeta: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.`,
  },
  {
    id: '6',
    name: 'Conjunto Fita Enseada',
    price: 64.90,
    oldPrice: 176.00,
    image: topFitaEnseada1,
    gallery: [
      topFitaEnseada1,
      topFitaEnseada2,
      topFitaEnseada3,
      topFitaEnseada4,
      topFitaEnseada5,
      topFitaEnseada6,
      topFitaEnseada7,
      topFitaEnseada8,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'conjunto',
    soldOut: true,
    description: `O Conjunto Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.
Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microganismos;

- Proteção Ultra Violeta: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.`,
  },
  {
    id: '7',
    name: 'Top Fita Preto',
    price: 39.90,
    oldPrice: 99.90,
    image: topFitaPreto1,
    gallery: [
      topFitaPreto1,
      topFitaPreto2,
      topFitaPreto3,
      topFitaPreto4,
      topFitaPreto5,
      topFitaPreto6,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'top',
    soldOut: true,
    description: `Top Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.
Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microganismos;

- Proteção Ultra Violeta: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.

Conforto extremo, proteção solar e a marquinha perfeita

Feito com poliamida e elastano, o Top Fita Preto tem toque macio, alta elasticidade e secagem rápida. Resistente ao desbotamento, ataques de micro-organismos e com proteção UV, ele é a escolha certa para curtir o verão com segurança, durabilidade e muito estilo.

O top perfeito para o verão e para a marquinha dos sonhos

O Top Fita Preto é o favorito de quem entende de verão. Com tecido leve e elástico, seca rápido, não desbota e ainda protege a pele com tecnologia UV. Resistente, durável e macio, ele une conforto e sensualidade com estilo — da praia ao feed.`,
  },
  {
    id: '8',
    name: 'Calcinha Fita Preto',
    price: 39.90,
    oldPrice: 99.90,
    image: calcinhaFitaPreto1,
    gallery: [
      calcinhaFitaPreto1,
      calcinhaFitaPreto2,
      calcinhaFitaPreto3,
      calcinhaFitaPreto4,
      calcinhaFitaPreto5,
      calcinhaFitaPreto6,
      calcinhaFitaPretoTabela,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'calcinha',
    soldOut: true,
    description: `Calcinha Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio. Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microrganismos;

- Proteção Ultra Violeta: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.`,
  },
  {
    id: '9',
    name: 'Top Fita Verde Frais',
    price: 39.90,
    oldPrice: 99.90,
    image: topFitaFrais1,
    gallery: [
      topFitaFrais1,
      topFitaFrais2,
      topFitaFrais3,
      topFitaFrais4,
      topFitaFrais5,
      topFitaFrais6,
      topFitaFrais7,
      topFitaFraisTabela,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'top',
    soldOut: true,
    description: `O top Fita é o queridinho da VS! Por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.

Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microrganismos;

- Proteção Ultra Violeta+50: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes`,
  },
  {
    id: '10',
    name: 'Calcinha Fita Verde Frais',
    price: 39.90,
    oldPrice: 99.90,
    image: calcinhaFitaFrais1,
    gallery: [
      calcinhaFitaFrais1,
      calcinhaFitaFrais2,
      calcinhaFitaFrais3,
      calcinhaFitaFrais4,
      calcinhaFitaFrais5,
      calcinhaFitaFrais6,
      calcinhaFitaFrais7,
      calcinhaFitaFrais8,
      calcinhaFitaFraisTabela,
    ],
    discount: '70%',
    sizes: ['P', 'M', 'G'],
    type: 'calcinha',
    soldOut: true,
    description: `Calcinha Fita é o clássico e queridinho da VS! por ser liso, inteiro e sem amarrações. É ideal para quem deseja a marquinha perfeita do verão. Extremamente confortável, se adapta perfeitamente ao corpo e tem toque super macio.

Apresenta o pingente VS banhado a ouro 18k.

- Poliamida + elastano criam um tecido macio e elástico;

- Secagem é super rápida, afinal, após um mergulho, ninguém quer ficar com um biquíni molhado por muito tempo, né?

- Durável e resistente ao desgaste, mesmo após várias utilizações e lavagens;

- Resistente ao ataque de microrganismos;

- Proteção Ultra Violeta+50: sua marquinha mais definida!

- Não desbota, mesmo após exposição ao sol e lavagens frequentes.`,
  },
];

