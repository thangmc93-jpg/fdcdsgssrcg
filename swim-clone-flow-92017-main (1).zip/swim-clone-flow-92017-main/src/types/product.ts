export interface Product {
  id: string;
  name: string;
  price: number;
  oldPrice: number;
  image: string;
  gallery?: string[];
  discount: '85%' | '70%';
  sizes: string[];
  topSizes?: string[]; // Tamanhos do top (para conjuntos)
  bottomSizes?: string[]; // Tamanhos da calcinha (para conjuntos)
  description?: string;
  type: 'conjunto' | 'top' | 'calcinha';
  soldOut?: boolean; // Indica se o produto está esgotado
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize: string;
  selectedBottomSize?: string;
}

export interface LunaCheckoutPayload {
  nome_produto: string;
  preco_original: string;
  preco_com_desconto: string;
  cupom: string;
  tipo_pagamento: string;
  quantidade: number;
  tamanho: string;
  tamanho_calcinha?: string;
  valor_total: string;
  desconto_pix: string;
  utm_source: string;
  utm_medium: string;
  utm_campaign: string;
  pixel: string;
}
