#!/bin/bash

# ============================================
# Script de Backup Automático
# Versiani Swim
# ============================================

set -e

# Configurações
BACKUP_DIR="/home/appuser/backups"
APP_DIR="/home/appuser/versiani-app"
DATE=$(date +%Y%m%d-%H%M%S)
RETENTION_DAYS=7

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   BACKUP AUTOMÁTICO                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Criar diretório de backup se não existir
mkdir -p $BACKUP_DIR

# Nome do arquivo de backup
BACKUP_FILE="$BACKUP_DIR/versiani-backup-$DATE.tar.gz"

echo -e "${YELLOW}📦 Criando backup...${NC}"

# Criar backup do frontend e backend
tar -czf $BACKUP_FILE \
    -C /home/appuser \
    versiani-app/frontend \
    versiani-app/backend

# Verificar se o backup foi criado
if [ -f "$BACKUP_FILE" ]; then
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    echo -e "${GREEN}✅ Backup criado com sucesso!${NC}"
    echo -e "${BLUE}Arquivo: ${BACKUP_FILE}${NC}"
    echo -e "${BLUE}Tamanho: ${SIZE}${NC}"
else
    echo -e "${RED}❌ Erro ao criar backup${NC}"
    exit 1
fi

# Remover backups antigos
echo -e "${YELLOW}🗑️  Removendo backups com mais de ${RETENTION_DAYS} dias...${NC}"
find $BACKUP_DIR -name "versiani-backup-*.tar.gz" -mtime +$RETENTION_DAYS -delete

# Listar backups disponíveis
echo ""
echo -e "${BLUE}📋 Backups disponíveis:${NC}"
ls -lh $BACKUP_DIR/versiani-backup-*.tar.gz 2>/dev/null || echo "Nenhum backup encontrado"

echo ""
echo -e "${GREEN}✅ Processo de backup concluído!${NC}"
