#!/bin/bash

# ============================================
# Script de Restauração de Backup
# Versiani Swim
# ============================================

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   RESTAURAR BACKUP                     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

BACKUP_DIR="/home/appuser/backups"

# Listar backups disponíveis
echo -e "${YELLOW}📋 Backups disponíveis:${NC}"
echo ""

backups=($(ls -t $BACKUP_DIR/versiani-backup-*.tar.gz 2>/dev/null))

if [ ${#backups[@]} -eq 0 ]; then
    echo -e "${RED}❌ Nenhum backup encontrado em ${BACKUP_DIR}${NC}"
    exit 1
fi

# Mostrar lista numerada
for i in "${!backups[@]}"; do
    SIZE=$(du -h "${backups[$i]}" | cut -f1)
    DATE=$(echo "${backups[$i]}" | grep -oP '\d{8}-\d{6}')
    echo -e "${BLUE}[$((i+1))]${NC} ${DATE} (${SIZE})"
done

echo ""
read -p "Escolha o número do backup para restaurar (1-${#backups[@]}): " CHOICE

# Validar escolha
if ! [[ "$CHOICE" =~ ^[0-9]+$ ]] || [ "$CHOICE" -lt 1 ] || [ "$CHOICE" -gt ${#backups[@]} ]; then
    echo -e "${RED}❌ Escolha inválida${NC}"
    exit 1
fi

BACKUP_FILE="${backups[$((CHOICE-1))]}"

echo ""
echo -e "${RED}⚠️  ATENÇÃO: Esta operação irá substituir os arquivos atuais!${NC}"
read -p "Tem certeza que deseja continuar? (sim/não): " CONFIRM

if [ "$CONFIRM" != "sim" ]; then
    echo -e "${YELLOW}Operação cancelada${NC}"
    exit 0
fi

# Parar backend
echo -e "${YELLOW}🛑 Parando backend...${NC}"
pm2 stop versiani-backend || true

# Fazer backup dos arquivos atuais
echo -e "${YELLOW}💾 Fazendo backup dos arquivos atuais...${NC}"
SAFETY_BACKUP="/home/appuser/backups/pre-restore-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf $SAFETY_BACKUP -C /home/appuser versiani-app/ 2>/dev/null || true

# Remover arquivos atuais
echo -e "${YELLOW}🗑️  Removendo arquivos atuais...${NC}"
rm -rf /home/appuser/versiani-app/frontend/*
rm -rf /home/appuser/versiani-app/backend/*

# Restaurar backup
echo -e "${YELLOW}📦 Restaurando backup...${NC}"
tar -xzf "$BACKUP_FILE" -C /home/appuser

# Ajustar permissões
chown -R appuser:appuser /home/appuser/versiani-app

# Reinstalar dependências do backend
echo -e "${YELLOW}📦 Reinstalando dependências...${NC}"
cd /home/appuser/versiani-app/backend
sudo -u appuser npm install

# Reiniciar backend
echo -e "${YELLOW}🚀 Reiniciando backend...${NC}"
pm2 restart versiani-backend

echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ✅ BACKUP RESTAURADO COM SUCESSO!    ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Backup de segurança salvo em:${NC}"
echo -e "${YELLOW}${SAFETY_BACKUP}${NC}"
echo ""
