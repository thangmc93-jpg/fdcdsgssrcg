#!/bin/bash

# ============================================
# Script de Restart Rápido
# Versiani Swim
# ============================================

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔄 Reiniciando serviços...${NC}"

# Reiniciar backend
echo -e "${YELLOW}Backend...${NC}"
pm2 restart versiani-backend

# Recarregar Nginx
echo -e "${YELLOW}Nginx...${NC}"
sudo systemctl reload nginx

# Verificar status
echo ""
echo -e "${GREEN}✅ Serviços reiniciados!${NC}"
echo ""
pm2 status versiani-backend
