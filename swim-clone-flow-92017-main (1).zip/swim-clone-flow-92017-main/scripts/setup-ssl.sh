#!/bin/bash

# ============================================
# Script de Configuração SSL (Let's Encrypt)
# Versiani Swim
# ============================================

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   CONFIGURAR SSL (HTTPS)               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Solicitar domínio e email
read -p "Digite seu domínio (ex: versiani.com.br): " DOMAIN
read -p "Digite seu email: " EMAIL

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
    echo -e "${RED}❌ Domínio e email são obrigatórios${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}🔍 Verificando se o domínio está apontando para este servidor...${NC}"

# Obter IP do servidor
SERVER_IP=$(curl -s ifconfig.me)
echo -e "${BLUE}IP do servidor: ${SERVER_IP}${NC}"

# Verificar DNS
DOMAIN_IP=$(dig +short ${DOMAIN} | tail -1)
echo -e "${BLUE}IP do domínio: ${DOMAIN_IP}${NC}"

if [ "$SERVER_IP" != "$DOMAIN_IP" ]; then
    echo -e "${RED}⚠️  ATENÇÃO: O domínio ainda não está apontando para este servidor!${NC}"
    echo -e "${YELLOW}Configure o DNS antes de continuar.${NC}"
    read -p "Deseja continuar mesmo assim? (s/N): " CONTINUE
    if [[ ! $CONTINUE =~ ^[Ss]$ ]]; then
        exit 0
    fi
fi

echo ""
echo -e "${YELLOW}📜 Obtendo certificado SSL...${NC}"
echo -e "${BLUE}Domínios: ${DOMAIN}, www.${DOMAIN}${NC}"
echo ""

# Obter certificado
certbot --nginx -d ${DOMAIN} -d www.${DOMAIN} \
    --non-interactive \
    --agree-tos \
    --email ${EMAIL} \
    --redirect

# Testar renovação automática
echo -e "${YELLOW}🧪 Testando renovação automática...${NC}"
certbot renew --dry-run

echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ✅ SSL CONFIGURADO COM SUCESSO!      ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}🌐 Seu site está disponível em:${NC}"
echo -e "   ${GREEN}https://${DOMAIN}${NC}"
echo -e "   ${GREEN}https://www.${DOMAIN}${NC}"
echo ""
echo -e "${YELLOW}📋 Renovação automática configurada!${NC}"
echo -e "O certificado será renovado automaticamente."
echo ""
