#!/bin/bash

# ============================================
# Script de Setup Inicial do VPS
# Versiani Swim - Configuração Automatizada
# ============================================

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   SETUP VPS - VERSIANI SWIM           ║${NC}"
echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo ""

# Verificar se está rodando como root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}❌ Este script precisa ser executado como root${NC}"
   echo -e "${YELLOW}Use: sudo ./setup-vps.sh${NC}"
   exit 1
fi

# Atualizar sistema
echo -e "${YELLOW}📦 Atualizando sistema...${NC}"
apt update && apt upgrade -y

# Instalar Node.js 20.x
echo -e "${YELLOW}📦 Instalando Node.js 20.x...${NC}"
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Instalar PM2 globalmente
echo -e "${YELLOW}📦 Instalando PM2...${NC}"
npm install -g pm2

# Instalar Nginx
echo -e "${YELLOW}📦 Instalando Nginx...${NC}"
apt install -y nginx

# Instalar Certbot para SSL
echo -e "${YELLOW}📦 Instalando Certbot...${NC}"
apt install -y certbot python3-certbot-nginx

# Criar usuário da aplicação
echo -e "${YELLOW}👤 Criando usuário appuser...${NC}"
if id "appuser" &>/dev/null; then
    echo -e "${GREEN}✅ Usuário appuser já existe${NC}"
else
    useradd -m -s /bin/bash appuser
    echo -e "${GREEN}✅ Usuário appuser criado${NC}"
fi

# Criar diretório da aplicação
echo -e "${YELLOW}📁 Criando estrutura de diretórios...${NC}"
mkdir -p /home/appuser/versiani-app/frontend
mkdir -p /home/appuser/versiani-app/backend
chown -R appuser:appuser /home/appuser/versiani-app

# Configurar firewall
echo -e "${YELLOW}🔥 Configurando firewall...${NC}"
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Configurar PM2 para iniciar no boot
echo -e "${YELLOW}⚙️  Configurando PM2 startup...${NC}"
su - appuser -c "pm2 startup systemd -u appuser --hp /home/appuser" | tail -1 | bash

echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ✅ SETUP CONCLUÍDO COM SUCESSO!     ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}📋 Próximos passos:${NC}"
echo -e "1. Faça upload do projeto usando deploy.sh"
echo -e "2. Configure o backend .env"
echo -e "3. Configure o Nginx usando setup-nginx.sh"
echo -e "4. Configure SSL usando setup-ssl.sh"
echo ""
echo -e "${YELLOW}Versões instaladas:${NC}"
node --version
npm --version
pm2 --version
nginx -v
