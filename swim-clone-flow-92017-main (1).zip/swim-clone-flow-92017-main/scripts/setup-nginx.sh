#!/bin/bash

# ============================================
# Script de Configuração do Nginx
# Versiani Swim
# ============================================

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   CONFIGURAR NGINX                     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Solicitar domínio
read -p "Digite seu domínio (ex: versiani.com.br): " DOMAIN

if [ -z "$DOMAIN" ]; then
    echo -e "${RED}❌ Domínio não pode estar vazio${NC}"
    exit 1
fi

echo -e "${YELLOW}📝 Criando configuração do Nginx...${NC}"

# Criar configuração do Nginx
cat > /etc/nginx/sites-available/versiani << EOF
server {
    listen 80;
    server_name ${DOMAIN} www.${DOMAIN};
    
    # Logs
    access_log /var/log/nginx/versiani_access.log;
    error_log /var/log/nginx/versiani_error.log;
    
    # Frontend React (arquivos estáticos)
    location / {
        root /home/appuser/versiani-app/frontend;
        try_files \$uri \$uri/ /index.html;
        
        # Cache para assets estáticos
        location ~* \.(jpg|jpeg|png|gif|ico|css|js|webp|svg|woff|woff2|ttf|eot)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
    
    # Backend API Node.js
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        
        # Headers necessários
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # Desabilitar cache
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Criar link simbólico
echo -e "${YELLOW}🔗 Ativando site...${NC}"
ln -sf /etc/nginx/sites-available/versiani /etc/nginx/sites-enabled/

# Remover configuração default se existir
rm -f /etc/nginx/sites-enabled/default

# Testar configuração
echo -e "${YELLOW}🧪 Testando configuração...${NC}"
nginx -t

# Recarregar Nginx
echo -e "${YELLOW}🔄 Recarregando Nginx...${NC}"
systemctl reload nginx

echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ✅ NGINX CONFIGURADO!                ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}📋 Próximos passos:${NC}"
echo -e "1. Configure o DNS do seu domínio apontando para este servidor"
echo -e "   A @ -> IP_DO_SERVIDOR"
echo -e "   A www -> IP_DO_SERVIDOR"
echo -e ""
echo -e "2. Aguarde propagação do DNS (até 24h)"
echo -e ""
echo -e "3. Execute: ${YELLOW}sudo ./setup-ssl.sh${NC}"
echo ""
