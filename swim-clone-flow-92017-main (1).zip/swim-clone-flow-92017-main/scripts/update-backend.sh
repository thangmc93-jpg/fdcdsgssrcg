#!/bin/bash

# ============================================
# Script de Atualização do Backend
# Versiani Swim
# ============================================

set -e

# CONFIGURAÇÕES
VPS_USER="appuser"
VPS_IP="SEU_IP_AQUI"
VPS_PATH="/home/appuser/versiani-app"
BACKEND_NAME="versiani-backend"

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   ATUALIZAR BACKEND                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Comprimir backend local
echo -e "${YELLOW}📦 Comprimindo backend...${NC}"
cd backend
tar -czf ../backend.tar.gz .
cd ..

# Upload para VPS
echo -e "${YELLOW}📤 Enviando para VPS...${NC}"
scp backend.tar.gz ${VPS_USER}@${VPS_IP}:${VPS_PATH}/

# Deploy no VPS
echo -e "${YELLOW}🚀 Atualizando no VPS...${NC}"
ssh ${VPS_USER}@${VPS_IP} << ENDSSH
cd ${VPS_PATH}

# Backup do .env atual
cp backend/.env backend/.env.backup

# Remover backend antigo
rm -rf backend/*

# Descompactar nova versão
tar -xzf backend.tar.gz -C backend/
rm backend.tar.gz

# Restaurar .env
mv backend/.env.backup backend/.env

# Instalar dependências
cd backend
npm install --production

# Reiniciar
pm2 restart ${BACKEND_NAME}

echo "✅ Backend atualizado!"
pm2 status ${BACKEND_NAME}
ENDSSH

# Limpar
rm backend.tar.gz

echo ""
echo -e "${GREEN}✅ Backend atualizado com sucesso!${NC}"
