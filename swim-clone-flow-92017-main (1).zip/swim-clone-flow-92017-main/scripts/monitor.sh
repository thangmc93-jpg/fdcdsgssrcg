#!/bin/bash

# ============================================
# Script de Monitoramento
# Versiani Swim
# ============================================

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   MONITORAMENTO - VERSIANI SWIM        ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo ""

# Status do Backend
echo -e "${YELLOW}🔍 Backend Status:${NC}"
pm2 status versiani-backend

# CPU e Memória
echo ""
echo -e "${YELLOW}💻 Recursos do Sistema:${NC}"
echo -e "${BLUE}CPU:${NC}"
top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1"%"}'

echo -e "${BLUE}Memória:${NC}"
free -h | grep Mem | awk '{print "Usado: " $3 " / Total: " $2 " (" int($3/$2 * 100) "%)"}'

echo -e "${BLUE}Disco:${NC}"
df -h / | tail -1 | awk '{print "Usado: " $3 " / Total: " $2 " (" $5 ")"}'

# Status do Nginx
echo ""
echo -e "${YELLOW}🌐 Nginx Status:${NC}"
systemctl status nginx --no-pager | head -3

# Testar API
echo ""
echo -e "${YELLOW}🔍 Testando API...${NC}"
HEALTH_CHECK=$(curl -s http://localhost:3001/api/health || echo "erro")

if [[ $HEALTH_CHECK == *"ok"* ]]; then
    echo -e "${GREEN}✅ API respondendo corretamente${NC}"
else
    echo -e "${RED}❌ API não está respondendo${NC}"
fi

# Logs recentes
echo ""
echo -e "${YELLOW}📋 Últimas 10 linhas do log:${NC}"
pm2 logs versiani-backend --lines 10 --nostream

# Certificado SSL
echo ""
echo -e "${YELLOW}🔒 Certificados SSL:${NC}"
if [ -d "/etc/letsencrypt/live" ]; then
    for cert in /etc/letsencrypt/live/*/cert.pem; do
        if [ -f "$cert" ]; then
            DOMAIN=$(basename $(dirname $cert))
            EXPIRY=$(openssl x509 -enddate -noout -in $cert | cut -d= -f2)
            echo -e "${BLUE}${DOMAIN}:${NC} expira em ${EXPIRY}"
        fi
    done
else
    echo -e "${YELLOW}Nenhum certificado SSL encontrado${NC}"
fi

# Backups disponíveis
echo ""
echo -e "${YELLOW}💾 Backups Recentes:${NC}"
ls -lht /home/appuser/backups/versiani-backup-*.tar.gz 2>/dev/null | head -5 || echo "Nenhum backup encontrado"

echo ""
echo -e "${GREEN}✅ Monitoramento concluído!${NC}"
