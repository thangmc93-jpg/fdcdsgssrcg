# 🚀 Scripts Automatizados - Versiani Swim

Scripts para facilitar o deploy e gerenciamento da sua loja no VPS.

## 📋 Índice de Scripts

### Setup Inicial (Execute no VPS)

#### 1. `setup-vps.sh` - Configuração Inicial do VPS
```bash
sudo ./setup-vps.sh
```
**O que faz:**
- Instala Node.js, PM2, Nginx e Certbot
- Cria usuário `appuser`
- Configura firewall
- Prepara estrutura de diretórios

**Quando usar:** Primeira vez que configurar o VPS

---

#### 2. `setup-nginx.sh` - Configurar Nginx
```bash
sudo ./setup-nginx.sh
```
**O que faz:**
- Cria configuração do Nginx para seu domínio
- Configura proxy reverso para o backend
- Ativa o site

**Quando usar:** Após upload inicial do projeto

---

#### 3. `setup-ssl.sh` - Instalar SSL (HTTPS)
```bash
sudo ./setup-ssl.sh
```
**O que faz:**
- Obtém certificado SSL gratuito do Let's Encrypt
- Configura HTTPS automático
- Ativa renovação automática

**Quando usar:** Após configurar DNS e Nginx

---

### Deploy (Execute Localmente)

#### 4. `deploy.sh` - Deploy Completo
```bash
./deploy.sh
```
**O que faz:**
- Faz build do frontend
- Cria backup no VPS
- Envia arquivos novos
- Reinicia serviços
- Verifica saúde da API

**Quando usar:** Para atualizar frontend e backend

---

#### 5. `update-backend.sh` - Atualizar Apenas Backend
```bash
./update-backend.sh
```
**O que faz:**
- Envia apenas arquivos do backend
- Preserva .env
- Reinstala dependências
- Reinicia PM2

**Quando usar:** Mudanças apenas no backend

---

### Manutenção (Execute no VPS)

#### 6. `backup.sh` - Criar Backup
```bash
./backup.sh
```
**O que faz:**
- Cria backup completo (frontend + backend)
- Remove backups antigos (>7 dias)
- Mostra lista de backups

**Quando usar:** Antes de mudanças importantes

**Dica:** Configure no cron para backups automáticos:
```bash
# Backup diário às 3h da manhã
0 3 * * * /home/appuser/scripts/backup.sh
```

---

#### 7. `restore.sh` - Restaurar Backup
```bash
sudo ./restore.sh
```
**O que faz:**
- Lista backups disponíveis
- Restaura versão escolhida
- Cria backup de segurança antes

**Quando usar:** Reverter para versão anterior

---

#### 8. `monitor.sh` - Monitorar Sistema
```bash
./monitor.sh
```
**O que faz:**
- Status do PM2 e Nginx
- Uso de CPU, memória e disco
- Testa API health
- Mostra logs recentes
- Verifica certificados SSL

**Quando usar:** Verificar saúde do sistema

---

#### 9. `quick-restart.sh` - Reiniciar Serviços
```bash
./quick-restart.sh
```
**O que faz:**
- Reinicia backend (PM2)
- Recarrega Nginx
- Mostra status

**Quando usar:** Após mudanças no .env ou configurações

---

## 🎯 Fluxo de Trabalho Recomendado

### Primeiro Deploy (Do Zero)

1. **No VPS (como root):**
```bash
# 1. Setup inicial
sudo ./scripts/setup-vps.sh

# 2. Transfira os arquivos do projeto
# (use deploy.sh local ou SCP manual)

# 3. Configure Nginx
sudo ./scripts/setup-nginx.sh

# 4. Configure DNS do domínio (no seu provedor)
# A @ -> IP_DO_VPS
# A www -> IP_DO_VPS

# 5. Aguarde propagação DNS (até 24h)

# 6. Instale SSL
sudo ./scripts/setup-ssl.sh
```

2. **No seu computador:**
```bash
# Edite as configurações do deploy.sh
nano deploy.sh
# VPS_IP="SEU_IP"
# DOMAIN="seudominio.com.br"

# Execute deploy
./deploy.sh
```

---

### Atualizações Futuras

**Deploy completo (frontend + backend):**
```bash
./deploy.sh
```

**Apenas backend:**
```bash
./scripts/update-backend.sh
```

**Apenas frontend:**
```bash
npm run build
scp -r dist/* appuser@SEU_IP:/home/appuser/versiani-app/frontend/
```

---

## 🔧 Configuração de Variáveis

Antes de usar os scripts de deploy, edite as configurações:

**`deploy.sh`:**
```bash
VPS_IP="191.252.xxx.xxx"  # IP do seu VPS
DOMAIN="versiani.com.br"   # Seu domínio
```

**`update-backend.sh`:**
```bash
VPS_IP="191.252.xxx.xxx"  # Mesmo IP
```

---

## 📊 Monitoramento e Logs

### Ver logs em tempo real:
```bash
pm2 logs versiani-backend
```

### Ver status dos serviços:
```bash
pm2 status
systemctl status nginx
```

### Ver logs do Nginx:
```bash
sudo tail -f /var/log/nginx/versiani_access.log
sudo tail -f /var/log/nginx/versiani_error.log
```

---

## 🆘 Solução de Problemas

### API não responde
```bash
./scripts/monitor.sh          # Verificar status
pm2 logs versiani-backend     # Ver erros
./scripts/quick-restart.sh    # Reiniciar
```

### Site fora do ar
```bash
sudo nginx -t                 # Testar config
sudo systemctl status nginx   # Ver status
sudo systemctl restart nginx  # Reiniciar
```

### Problemas após atualização
```bash
sudo ./scripts/restore.sh     # Voltar versão anterior
```

---

## 🔒 Segurança

### Permissões dos Scripts
```bash
chmod +x scripts/*.sh
```

### Nunca commite:
- ❌ Arquivo `.env` com credenciais
- ❌ IPs reais nos scripts
- ❌ Chaves da API Vega

---

## 📦 Estrutura de Arquivos no VPS

```
/home/appuser/
├── versiani-app/
│   ├── frontend/          # Build do React
│   │   ├── index.html
│   │   ├── assets/
│   │   └── ...
│   └── backend/           # API Node.js
│       ├── server.js
│       ├── .env          # Configurações
│       └── routes/
├── backups/              # Backups automáticos
│   ├── versiani-backup-20250120-030000.tar.gz
│   └── ...
└── scripts/              # Scripts de manutenção
    ├── backup.sh
    ├── monitor.sh
    └── ...
```

---

## 🎓 Dicas Úteis

1. **Backups automáticos:** Configure cron para executar `backup.sh` diariamente
2. **Monitoramento:** Execute `monitor.sh` regularmente
3. **Antes de updates:** Sempre faça backup com `backup.sh`
4. **Logs:** Use `pm2 logs` para debugar problemas
5. **SSL:** Renovação é automática, mas monitore a validade

---

## 📞 Suporte

- **Problemas com scripts:** Verifique logs e permissões
- **Erros no deploy:** Execute `monitor.sh` para diagnóstico
- **VPS offline:** Contate seu provedor de VPS
- **API Vega:** Suporte da Vega Checkout

---

## ✅ Checklist de Deploy

- [ ] VPS configurado (`setup-vps.sh`)
- [ ] Nginx configurado (`setup-nginx.sh`)
- [ ] DNS apontando para VPS
- [ ] SSL instalado (`setup-ssl.sh`)
- [ ] Backend `.env` configurado
- [ ] Deploy executado (`deploy.sh`)
- [ ] API health OK (`monitor.sh`)
- [ ] Site acessível via HTTPS
- [ ] Checkout testado
- [ ] IP VPS adicionado no painel Vega
